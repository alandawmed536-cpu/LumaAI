package com.example.data

import com.example.model.AppCategory
import com.example.model.VirtualApp
import com.example.model.VmInstance
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

class LumaRepository {

    private val _installedApps = MutableStateFlow<List<VirtualApp>>(defaultVirtualApps)
    val installedApps: StateFlow<List<VirtualApp>> = _installedApps.asStateFlow()

    private val _vmInstances = MutableStateFlow<List<VmInstance>>(defaultVmInstances)
    val vmInstances: StateFlow<List<VmInstance>> = _vmInstances.asStateFlow()

    fun installApp(app: VirtualApp) {
        if (_installedApps.value.none { it.id == app.id }) {
            _installedApps.value = _installedApps.value + app
        }
    }

    fun uninstallApp(appId: String) {
        _installedApps.value = _installedApps.value.filterNot { it.id == appId && !it.isSystemApp }
    }

    fun toggleAppRunningState(appId: String, isRunning: Boolean) {
        _installedApps.value = _installedApps.value.map { app ->
            if (app.id == appId) app.copy(isRunning = isRunning) else app
        }
    }

    fun updateVmInstance(vm: VmInstance) {
        _vmInstances.value = _vmInstances.value.map {
            if (it.id == vm.id) vm else it
        }
    }

    companion object {
        val defaultVirtualApps = listOf(
            VirtualApp(
                id = "luma_ai",
                name = "Luma AI Core",
                category = AppCategory.AI_TOOLS,
                iconName = "Psychology",
                packageName = "com.lumaai.os.core",
                version = "4.2.0-pro",
                description = "LumaAI's primary neural assistant for device optimization and smart automation.",
                isSystemApp = true
            ),
            VirtualApp(
                id = "vm_manager",
                name = "VM Subsystem",
                category = AppCategory.SYSTEM,
                iconName = "Phonelink",
                packageName = "com.lumaai.os.vmos",
                version = "3.5.1",
                description = "Virtual Android phone instance manager. Configure RAM, CPU, Root & display specs.",
                isSystemApp = true
            ),
            VirtualApp(
                id = "luma_settings",
                name = "Luma Settings",
                category = AppCategory.SYSTEM,
                iconName = "Settings",
                packageName = "com.lumaai.os.settings",
                version = "4.2.0",
                description = "System customization, branding information, developer sandbox, and wallpapers.",
                isSystemApp = true
            ),
            VirtualApp(
                id = "luma_terminal",
                name = "Virtual Shell",
                category = AppCategory.DEVELOPER,
                iconName = "Terminal",
                packageName = "com.lumaai.os.terminal",
                version = "2.1.0",
                description = "Linux bash and Android ADB terminal shell inside the LumaAI virtual environment.",
                isSystemApp = true
            ),
            VirtualApp(
                id = "luma_files",
                name = "Virtual Files",
                category = AppCategory.UTILITIES,
                iconName = "Folder",
                packageName = "com.lumaai.os.files",
                version = "1.8.4",
                description = "Isolated storage manager for virtual APKs, system logs, and user downloads.",
                isSystemApp = true
            ),
            VirtualApp(
                id = "luma_store",
                name = "Luma App Store",
                category = AppCategory.AI_TOOLS,
                iconName = "ShoppingBag",
                packageName = "com.lumaai.os.store",
                version = "3.0.1",
                description = "Browse and install virtual apps and AI plugins directly into LumaAI OS.",
                isSystemApp = true
            ),
            VirtualApp(
                id = "luma_camera",
                name = "AI Vision Cam",
                category = AppCategory.MEDIA,
                iconName = "CameraAlt",
                packageName = "com.lumaai.os.camera",
                version = "2.0.0",
                description = "Virtual camera with real-time AI image analysis and neural filters.",
                isSystemApp = true
            ),
            VirtualApp(
                id = "luma_browser",
                name = "Luma Web",
                category = AppCategory.MEDIA,
                iconName = "Public",
                packageName = "com.lumaai.os.browser",
                version = "5.1.2",
                description = "High-speed isolated web sandbox with built-in ad block and AI summarize.",
                isSystemApp = false
            ),
            VirtualApp(
                id = "luma_notes",
                name = "AI Notes",
                category = AppCategory.UTILITIES,
                iconName = "EditNote",
                packageName = "com.lumaai.os.notes",
                version = "1.4.0",
                description = "Markdown notepad with AI code generation and text summarization.",
                isSystemApp = false
            ),
            VirtualApp(
                id = "luma_phone",
                name = "Virtual Phone",
                category = AppCategory.UTILITIES,
                iconName = "Call",
                packageName = "com.lumaai.os.dialer",
                version = "1.0.0",
                description = "Virtual dialer and AI VoIP calls simulator.",
                isSystemApp = false
            ),
            VirtualApp(
                id = "luma_messages",
                name = "Luma SMS",
                category = AppCategory.UTILITIES,
                iconName = "Chat",
                packageName = "com.lumaai.os.sms",
                version = "1.2.0",
                description = "Smart AI messaging suite with automated auto-replies.",
                isSystemApp = false
            ),
            VirtualApp(
                id = "luma_cleaner",
                name = "RAM Optimizer",
                category = AppCategory.SYSTEM,
                iconName = "Speed",
                packageName = "com.lumaai.os.cleaner",
                version = "2.2.0",
                description = "Instant 1-tap memory purge and virtual CPU booster.",
                isSystemApp = true
            )
        )

        val defaultVmInstances = listOf(
            VmInstance(
                id = "vm_main",
                name = "LumaAI OS - Main Phone",
                androidVersion = "Android 15 (Luma Engine 4.2)",
                ramAllocatedGb = 8,
                cpuCores = 8,
                isRooted = true,
                isActive = true
            ),
            VmInstance(
                id = "vm_sandbox",
                name = "Isolated Sandbox Instance",
                androidVersion = "Android 14 (Luma Shield)",
                ramAllocatedGb = 4,
                cpuCores = 4,
                isRooted = false,
                isActive = false
            ),
            VmInstance(
                id = "vm_gaming",
                name = "Gaming & High-FPS Profile",
                androidVersion = "Android 15 (Luma Ultra)",
                ramAllocatedGb = 12,
                cpuCores = 8,
                isRooted = true,
                isActive = false
            )
        )
    }
}
