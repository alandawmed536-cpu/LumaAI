package com.example.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.LumaRepository
import com.example.model.AiMessage
import com.example.model.LumaNotification
import com.example.model.ScreenState
import com.example.model.SystemStats
import com.example.model.VirtualApp
import com.example.model.VmInstance
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.random.Random

class LumaOSViewModel(
    private val repository: LumaRepository = LumaRepository()
) : ViewModel() {

    val installedApps = repository.installedApps
    val vmInstances = repository.vmInstances

    private val _currentScreen = MutableStateFlow(ScreenState.HOME)
    val currentScreen: StateFlow<ScreenState> = _currentScreen.asStateFlow()

    private val _activeApp = MutableStateFlow<VirtualApp?>(null)
    val activeApp: StateFlow<VirtualApp?> = _activeApp.asStateFlow()

    private val _runningApps = MutableStateFlow<List<VirtualApp>>(emptyList())
    val runningApps: StateFlow<List<VirtualApp>> = _runningApps.asStateFlow()

    private val _systemStats = MutableStateFlow(
        SystemStats(
            ramUsedMb = 3480,
            ramTotalMb = 8192,
            cpuLoadPct = 18f,
            batteryPct = 98,
            fps = 120,
            rootStatus = true
        )
    )
    val systemStats: StateFlow<SystemStats> = _systemStats.asStateFlow()

    private val _quickSettingsOpen = MutableStateFlow(false)
    val quickSettingsOpen: StateFlow<Boolean> = _quickSettingsOpen.asStateFlow()

    private val _aiSheetOpen = MutableStateFlow(false)
    val aiSheetOpen: StateFlow<Boolean> = _aiSheetOpen.asStateFlow()

    private val _floatingBallOpen = MutableStateFlow(true)
    val floatingBallOpen: StateFlow<Boolean> = _floatingBallOpen.asStateFlow()

    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    private val _notifications = MutableStateFlow<List<LumaNotification>>(
        listOf(
            LumaNotification(
                id = "n1",
                title = "LumaAI OS Kernel Ready",
                message = "Virtual Machine environment loaded cleanly. Luma Core v4.2 active.",
                timestamp = "Just now",
                category = "System"
            ),
            LumaNotification(
                id = "n2",
                title = "Virtual Root Access Granted",
                message = "SU sandbox permissions enabled for Luma Shell and VM Subsystem.",
                timestamp = "2m ago",
                category = "Security"
            )
        )
    )
    val notifications: StateFlow<List<LumaNotification>> = _notifications.asStateFlow()

    private val _aiMessages = MutableStateFlow<List<AiMessage>>(
        listOf(
            AiMessage(
                id = "m1",
                sender = "LumaAI",
                text = "Hello! I am your LumaAI OS Core Assistant. How can I help optimize your virtual mobile environment today?",
                timestamp = getCurrentTime()
            )
        )
    )
    val aiMessages: StateFlow<List<AiMessage>> = _aiMessages.asStateFlow()

    private val _activeTheme = MutableStateFlow("Obsidian Neon")
    val activeTheme: StateFlow<String> = _activeTheme.asStateFlow()

    init {
        // Dynamic stats telemetry loop
        viewModelScope.launch {
            while (true) {
                delay(3000)
                val current = _systemStats.value
                val newCpu = (12f + Random.nextFloat() * 18f).coerceIn(5f, 95f)
                val ramVariation = Random.nextInt(-40, 45)
                val newRam = (current.ramUsedMb + ramVariation).coerceIn(2100, 7800)
                _systemStats.value = current.copy(
                    cpuLoadPct = newCpu,
                    ramUsedMb = newRam
                )
            }
        }
    }

    fun navigateTo(screen: ScreenState) {
        _currentScreen.value = screen
        _quickSettingsOpen.value = false
    }

    fun openApp(app: VirtualApp) {
        _activeApp.value = app
        _currentScreen.value = ScreenState.VIRTUAL_APP_RUNNING
        repository.toggleAppRunningState(app.id, true)
        if (_runningApps.value.none { it.id == app.id }) {
            _runningApps.value = _runningApps.value + app
        }
    }

    fun closeActiveApp() {
        _activeApp.value = null
        _currentScreen.value = ScreenState.HOME
    }

    fun closeSpecificApp(appId: String) {
        repository.toggleAppRunningState(appId, false)
        _runningApps.value = _runningApps.value.filterNot { it.id == appId }
        if (_activeApp.value?.id == appId) {
            closeActiveApp()
        }
    }

    fun clearAllRecentApps() {
        _runningApps.value.forEach { app ->
            repository.toggleAppRunningState(app.id, false)
        }
        _runningApps.value = emptyList()
        _activeApp.value = null
        _currentScreen.value = ScreenState.HOME
        optimizeRam()
    }

    fun toggleQuickSettings() {
        _quickSettingsOpen.value = !_quickSettingsOpen.value
    }

    fun toggleAiSheet() {
        _aiSheetOpen.value = !_aiSheetOpen.value
    }

    fun toggleFloatingBall() {
        _floatingBallOpen.value = !_floatingBallOpen.value
    }

    fun setSearchQuery(query: String) {
        _searchQuery.value = query
    }

    fun optimizeRam() {
        val current = _systemStats.value
        _systemStats.value = current.copy(
            ramUsedMb = (2200..2600).random(),
            cpuLoadPct = 8.5f
        )
        addNotification(
            title = "RAM Boost Complete",
            message = "Freed 1.2 GB virtual memory. Luma Kernel performance set to Ultra.",
            category = "System"
        )
    }

    fun toggleRootAccess() {
        val current = _systemStats.value
        val newRoot = !current.rootStatus
        _systemStats.value = current.copy(rootStatus = newRoot)
        addNotification(
            title = if (newRoot) "Virtual Root Enabled" else "Virtual Root Disabled",
            message = if (newRoot) "SU root sandbox active for VM apps." else "SU root sandbox revoked.",
            category = "Security"
        )
    }

    fun switchTheme(themeName: String) {
        _activeTheme.value = themeName
    }

    fun sendAiPrompt(promptText: String) {
        if (promptText.isBlank()) return
        val userMsg = AiMessage(
            id = System.currentTimeMillis().toString(),
            sender = "User",
            text = promptText,
            timestamp = getCurrentTime()
        )
        _aiMessages.value = _aiMessages.value + userMsg

        viewModelScope.launch {
            delay(800)
            val reply = generateLumaResponse(promptText)
            val aiMsg = AiMessage(
                id = (System.currentTimeMillis() + 1).toString(),
                sender = "LumaAI",
                text = reply,
                timestamp = getCurrentTime(),
                isCodeOrScript = promptText.lowercase().contains("script") || promptText.lowercase().contains("code") || promptText.lowercase().contains("shell")
            )
            _aiMessages.value = _aiMessages.value + aiMsg
        }
    }

    private fun generateLumaResponse(prompt: String): String {
        val lower = prompt.lowercase()
        return when {
            "boost" in lower || "ram" in lower || "speed" in lower || "clean" in lower -> {
                optimizeRam()
                "⚡ Virtual RAM purged! Released 1,280 MB of cached memory and locked frame rate to 120 FPS in Luma OS."
            }
            "root" in lower -> {
                toggleRootAccess()
                "🔐 Virtual Root access toggled. VM sandbox privileges updated."
            }
            "app" in lower || "install" in lower -> {
                "📱 You can install and launch new virtual applications from the Luma App Store or Virtual File Manager."
            }
            "vmos" in lower || "vm" in lower || "subsystem" in lower -> {
                "💻 LumaAI Virtual Machine Subsystem is running Luma OS Kernel v4.2 with 8GB RAM and 8 CPU cores allocated."
            }
            "who" in lower || "developer" in lower || "creator" in lower -> {
                "🚀 LumaAI OS is developed by LumaAI Technologies — Next-Gen Virtual Android Mobile OS & AI Launcher."
            }
            else -> {
                "🤖 LumaAI Assistant: Executed analysis on Luma OS Kernel. System state optimal. Anything else you need me to adjust or automate?"
            }
        }
    }

    fun installVirtualApp(app: VirtualApp) {
        repository.installApp(app)
        addNotification(
            title = "App Installed",
            message = "${app.name} (${app.packageName}) installed into Luma OS sandbox.",
            category = "Store"
        )
    }

    fun uninstallVirtualApp(appId: String) {
        repository.uninstallApp(appId)
        closeSpecificApp(appId)
    }

    fun addNotification(title: String, message: String, category: String = "System") {
        val newNotif = LumaNotification(
            id = System.currentTimeMillis().toString(),
            title = title,
            message = message,
            timestamp = "Just now",
            category = category
        )
        _notifications.value = listOf(newNotif) + _notifications.value
    }

    fun clearNotifications() {
        _notifications.value = emptyList()
    }

    private fun getCurrentTime(): String {
        return SimpleDateFormat("hh:mm a", Locale.getDefault()).format(Date())
    }
}
