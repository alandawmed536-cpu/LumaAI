package com.example.model

import androidx.compose.ui.graphics.vector.ImageVector

data class VirtualApp(
    val id: String,
    val name: String,
    val category: AppCategory,
    val iconName: String, // Material icon mapping name
    val packageName: String,
    val version: String = "1.0.0",
    val description: String = "",
    val isSystemApp: Boolean = false,
    val isRunning: Boolean = false,
    val installTime: Long = System.currentTimeMillis()
)

enum class AppCategory(val displayName: String) {
    SYSTEM("System & OS"),
    AI_TOOLS("Luma AI Tools"),
    UTILITIES("Utilities"),
    DEVELOPER("Dev & Sandbox"),
    MEDIA("Media & Web")
}

data class VmInstance(
    val id: String,
    val name: String,
    val androidVersion: String,
    val ramAllocatedGb: Int,
    val cpuCores: Int,
    val isRooted: Boolean,
    val is64Bit: Boolean = true,
    val resolution: String = "1080 x 2400",
    val isActive: Boolean = false
)

data class SystemStats(
    val ramUsedMb: Int,
    val ramTotalMb: Int = 8192,
    val cpuLoadPct: Float,
    val batteryPct: Int = 98,
    val isCharging: Boolean = true,
    val fps: Int = 120,
    val temperatureC: Float = 34.5f,
    val storageUsedGb: Float = 14.2f,
    val storageTotalGb: Float = 128.0f,
    val rootStatus: Boolean = true
)

data class LumaNotification(
    val id: String,
    val title: String,
    val message: String,
    val timestamp: String,
    val category: String = "System",
    val isRead: Boolean = false
)

data class AiMessage(
    val id: String,
    val sender: String, // "User" or "LumaAI"
    val text: String,
    val timestamp: String = "Just now",
    val isCodeOrScript: Boolean = false
)

enum class ScreenState {
    HOME,
    APP_DRAWER,
    RECENTS,
    SETTINGS,
    VM_MANAGER,
    AI_ASSISTANT,
    LOCK_SCREEN,
    VIRTUAL_APP_RUNNING
}
