package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.model.ScreenState
import com.example.ui.components.LumaFloatingBall
import com.example.ui.components.LumaNavBar
import com.example.ui.components.LumaStatusBar
import com.example.ui.components.QuickSettingsSheet
import com.example.ui.screens.LumaAiAssistantSheet
import com.example.ui.screens.LumaAppDrawer
import com.example.ui.screens.LumaHomeScreen
import com.example.ui.screens.LumaRecentsScreen
import com.example.ui.screens.LumaSettingsScreen
import com.example.ui.screens.VirtualAppContainerScreen
import com.example.ui.theme.LumaOSTheme
import com.example.viewmodel.LumaOSViewModel

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            LumaOSTheme {
                LumaOSApp()
            }
        }
    }
}

@Composable
fun LumaOSApp(
    viewModel: LumaOSViewModel = viewModel()
) {
    val currentScreen by viewModel.currentScreen.collectAsStateWithLifecycle()
    val activeApp by viewModel.activeApp.collectAsStateWithLifecycle()
    val installedApps by viewModel.installedApps.collectAsStateWithLifecycle()
    val vmInstances by viewModel.vmInstances.collectAsStateWithLifecycle()
    val systemStats by viewModel.systemStats.collectAsStateWithLifecycle()
    val runningApps by viewModel.runningApps.collectAsStateWithLifecycle()
    val quickSettingsOpen by viewModel.quickSettingsOpen.collectAsStateWithLifecycle()
    val aiSheetOpen by viewModel.aiSheetOpen.collectAsStateWithLifecycle()
    val floatingBallOpen by viewModel.floatingBallOpen.collectAsStateWithLifecycle()
    val searchQuery by viewModel.searchQuery.collectAsStateWithLifecycle()
    val notifications by viewModel.notifications.collectAsStateWithLifecycle()
    val aiMessages by viewModel.aiMessages.collectAsStateWithLifecycle()
    val activeTheme by viewModel.activeTheme.collectAsStateWithLifecycle()

    val activeVm = vmInstances.firstOrNull { it.isActive } ?: vmInstances.first()

    // Android Hardware Back Gesture / Button Handler
    BackHandler(enabled = currentScreen != ScreenState.HOME || quickSettingsOpen || aiSheetOpen) {
        when {
            quickSettingsOpen -> viewModel.toggleQuickSettings()
            aiSheetOpen -> viewModel.toggleAiSheet()
            currentScreen == ScreenState.VIRTUAL_APP_RUNNING -> viewModel.closeActiveApp()
            else -> viewModel.navigateTo(ScreenState.HOME)
        }
    }

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        bottomBar = {
            LumaNavBar(
                onBack = {
                    when {
                        quickSettingsOpen -> viewModel.toggleQuickSettings()
                        aiSheetOpen -> viewModel.toggleAiSheet()
                        currentScreen == ScreenState.VIRTUAL_APP_RUNNING -> viewModel.closeActiveApp()
                        else -> viewModel.navigateTo(ScreenState.HOME)
                    }
                },
                onHome = {
                    if (quickSettingsOpen) viewModel.toggleQuickSettings()
                    if (aiSheetOpen) viewModel.toggleAiSheet()
                    viewModel.navigateTo(ScreenState.HOME)
                },
                onRecents = {
                    viewModel.navigateTo(ScreenState.RECENTS)
                },
                onAiAssistant = {
                    viewModel.toggleAiSheet()
                }
            )
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            // Main Virtual OS Screen Content
            Column(modifier = Modifier.fillMaxSize()) {
                // Top Glassmorphic Luma Status Bar
                LumaStatusBar(
                    stats = systemStats,
                    onPullDown = { viewModel.toggleQuickSettings() }
                )

                Box(modifier = Modifier.weight(1f)) {
                    when (currentScreen) {
                        ScreenState.HOME -> {
                            LumaHomeScreen(
                                installedApps = installedApps,
                                stats = systemStats,
                                activeVm = activeVm,
                                searchQuery = searchQuery,
                                onQueryChange = { viewModel.setSearchQuery(it) },
                                onOpenApp = { viewModel.openApp(it) },
                                onOpenAppDrawer = { viewModel.navigateTo(ScreenState.APP_DRAWER) },
                                onOpenAi = { viewModel.toggleAiSheet() },
                                onOpenVmManager = { viewModel.navigateTo(ScreenState.SETTINGS) },
                                onBoostRam = { viewModel.optimizeRam() }
                            )
                        }

                        ScreenState.APP_DRAWER -> {
                            LumaAppDrawer(
                                installedApps = installedApps,
                                onOpenApp = { viewModel.openApp(it) },
                                onUninstallApp = { viewModel.uninstallVirtualApp(it) },
                                onCloseDrawer = { viewModel.navigateTo(ScreenState.HOME) }
                            )
                        }

                        ScreenState.RECENTS -> {
                            LumaRecentsScreen(
                                runningApps = runningApps,
                                onOpenApp = { viewModel.openApp(it) },
                                onCloseApp = { viewModel.closeSpecificApp(it) },
                                onClearAll = { viewModel.clearAllRecentApps() },
                                onCloseRecents = { viewModel.navigateTo(ScreenState.HOME) }
                            )
                        }

                        ScreenState.SETTINGS, ScreenState.VM_MANAGER -> {
                            LumaSettingsScreen(
                                stats = systemStats,
                                activeVm = activeVm,
                                activeTheme = activeTheme,
                                onToggleRoot = { viewModel.toggleRootAccess() },
                                onSwitchTheme = { viewModel.switchTheme(it) },
                                onOptimizeRam = { viewModel.optimizeRam() },
                                onCloseSettings = { viewModel.navigateTo(ScreenState.HOME) }
                            )
                        }

                        ScreenState.VIRTUAL_APP_RUNNING -> {
                            activeApp?.let { app ->
                                VirtualAppContainerScreen(
                                    app = app,
                                    onCloseApp = { viewModel.closeActiveApp() },
                                    onInstallApp = { viewModel.installVirtualApp(it) }
                                )
                            } ?: run {
                                viewModel.navigateTo(ScreenState.HOME)
                            }
                        }

                        else -> {
                            LumaHomeScreen(
                                installedApps = installedApps,
                                stats = systemStats,
                                activeVm = activeVm,
                                searchQuery = searchQuery,
                                onQueryChange = { viewModel.setSearchQuery(it) },
                                onOpenApp = { viewModel.openApp(it) },
                                onOpenAppDrawer = { viewModel.navigateTo(ScreenState.APP_DRAWER) },
                                onOpenAi = { viewModel.toggleAiSheet() },
                                onOpenVmManager = { viewModel.navigateTo(ScreenState.SETTINGS) },
                                onBoostRam = { viewModel.optimizeRam() }
                            )
                        }
                    }
                }
            }

            // Quick Settings Pull-Down Overlay
            QuickSettingsSheet(
                isOpen = quickSettingsOpen,
                stats = systemStats,
                notifications = notifications,
                activeTheme = activeTheme,
                onDismiss = { viewModel.toggleQuickSettings() },
                onBoostRam = { viewModel.optimizeRam() },
                onToggleRoot = { viewModel.toggleRootAccess() },
                onOpenSettings = {
                    viewModel.toggleQuickSettings()
                    viewModel.navigateTo(ScreenState.SETTINGS)
                },
                onOpenAi = {
                    viewModel.toggleQuickSettings()
                    viewModel.toggleAiSheet()
                },
                onSwitchTheme = { viewModel.switchTheme(it) },
                onClearNotifs = { viewModel.clearNotifications() }
            )

            // AI Core Assistant Sheet Overlay
            LumaAiAssistantSheet(
                isOpen = aiSheetOpen,
                messages = aiMessages,
                onSendPrompt = { viewModel.sendAiPrompt(it) },
                onDismiss = { viewModel.toggleAiSheet() }
            )

            // VMOS Floating Ball Overlay
            if (floatingBallOpen && !quickSettingsOpen && !aiSheetOpen) {
                LumaFloatingBall(
                    onHome = { viewModel.navigateTo(ScreenState.HOME) },
                    onBoostRam = { viewModel.optimizeRam() },
                    onOpenAi = { viewModel.toggleAiSheet() },
                    onOpenVmManager = { viewModel.navigateTo(ScreenState.SETTINGS) },
                    onOpenSettings = { viewModel.navigateTo(ScreenState.SETTINGS) },
                    onToggleRoot = { viewModel.toggleRootAccess() },
                    modifier = Modifier
                        .align(Alignment.BottomEnd)
                        .padding(bottom = 20.dp, end = 16.dp)
                )
            }
        }
    }
}
