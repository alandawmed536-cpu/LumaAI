package com.example.ui.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.KeyboardArrowUp
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.model.SystemStats
import com.example.model.VirtualApp
import com.example.model.VmInstance
import com.example.ui.components.AiSearchWidget
import com.example.ui.components.GreetingClockWidget
import com.example.ui.components.IconHelper
import com.example.ui.components.SystemPerformanceWidget
import com.example.ui.components.VmInstanceWidget

@Composable
fun LumaHomeScreen(
    installedApps: List<VirtualApp>,
    stats: SystemStats,
    activeVm: VmInstance,
    searchQuery: String,
    onQueryChange: (String) -> Unit,
    onOpenApp: (VirtualApp) -> Unit,
    onOpenAppDrawer: () -> Unit,
    onOpenAi: () -> Unit,
    onOpenVmManager: () -> Unit,
    onBoostRam: () -> Unit,
    modifier: Modifier = Modifier
) {
    val scrollState = rememberScrollState()

    // Filter main desktop apps (first 8) and dock apps (5)
    val desktopApps = installedApps.take(8)
    val dockAppIds = listOf("luma_ai", "luma_files", "luma_store", "luma_terminal", "luma_settings")
    val dockApps = installedApps.filter { it.id in dockAppIds }

    Box(modifier = modifier.fillMaxSize()) {
        // Futuristic Wallpaper Background
        Image(
            painter = painterResource(id = R.drawable.luma_os_wallpaper),
            contentDescription = "Luma OS Wallpaper",
            contentScale = ContentScale.Crop,
            modifier = Modifier.fillMaxSize()
        )

        // Subtle dark ambient overlay
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    Brush.verticalGradient(
                        colors = listOf(
                            Color.Black.copy(alpha = 0.4f),
                            Color.Transparent,
                            Color.Black.copy(alpha = 0.7f)
                        )
                    )
                )
        )

        // Main Desktop Content
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(scrollState)
                .padding(horizontal = 16.dp, vertical = 8.dp)
        ) {
            // Clock & Greeting
            GreetingClockWidget()

            Spacer(modifier = Modifier.height(12.dp))

            // AI Prompt / Search
            AiSearchWidget(
                query = searchQuery,
                onQueryChange = onQueryChange,
                onSearchSubmit = { onOpenAi() },
                onOpenAi = onOpenAi
            )

            Spacer(modifier = Modifier.height(16.dp))

            // Telemetry Gauge
            SystemPerformanceWidget(stats = stats, onBoostRam = onBoostRam)

            Spacer(modifier = Modifier.height(12.dp))

            // VM Subsystem Widget
            VmInstanceWidget(activeVm = activeVm, onOpenVmManager = onOpenVmManager)

            Spacer(modifier = Modifier.height(20.dp))

            // Desktop Apps Grid Label
            Text(
                text = "Luma OS Apps",
                color = Color.White.copy(alpha = 0.9f),
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(start = 4.dp, bottom = 12.dp)
            )

            // Desktop App Icons Grid (4 columns)
            Column(verticalArrangement = Arrangement.spacedBy(16.dp)) {
                desktopApps.chunked(4).forEach { rowApps ->
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceAround
                    ) {
                        rowApps.forEach { app ->
                            AppIconItem(
                                app = app,
                                onClick = { onOpenApp(app) },
                                modifier = Modifier.weight(1f)
                            )
                        }
                        // Fill empty slots if needed
                        repeat(4 - rowApps.size) {
                            Spacer(modifier = Modifier.weight(1f))
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(24.dp))

            // Swipe Up for App Drawer Handle
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { onOpenAppDrawer() }
                    .padding(12.dp),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(
                        imageVector = Icons.Default.KeyboardArrowUp,
                        contentDescription = "Swipe up for all apps",
                        tint = Color(0xFF38BDF8),
                        modifier = Modifier.size(20.dp)
                    )
                    Text(
                        text = "Swipe or tap for App Drawer (${installedApps.size} apps)",
                        color = Color(0xFF94A3B8),
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Medium
                    )
                }
            }

            Spacer(modifier = Modifier.height(90.dp)) // Dock spacing
        }

        // Bottom Fixed Dock Bar
        Box(
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .padding(bottom = 12.dp, start = 16.dp, end = 16.dp)
                .fillMaxWidth()
                .clip(RoundedCornerShape(28.dp))
                .background(
                    Brush.verticalGradient(
                        colors = listOf(
                            Color(0xFF131B2E).copy(alpha = 0.92f),
                            Color(0xFF090D16).copy(alpha = 0.95f)
                        )
                    )
                )
                .border(1.dp, Color(0xFF38BDF8).copy(alpha = 0.35f), RoundedCornerShape(28.dp))
                .padding(vertical = 10.dp, horizontal = 12.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceAround,
                verticalAlignment = Alignment.CenterVertically
            ) {
                dockApps.forEach { app ->
                    AppDockIconItem(app = app, onClick = { onOpenApp(app) })
                }
            }
        }
    }
}

@Composable
fun AppIconItem(
    app: VirtualApp,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .clip(RoundedCornerShape(16.dp))
            .clickable(onClick = onClick)
            .padding(6.dp)
            .testTag("app_icon_${app.id}"),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Box(
            modifier = Modifier
                .size(52.dp)
                .clip(RoundedCornerShape(16.dp))
                .background(
                    Brush.linearGradient(
                        colors = listOf(
                            Color(0xFF1E293B),
                            Color(0xFF0F172A)
                        )
                    )
                )
                .border(1.5.dp, Color(0xFF38BDF8).copy(alpha = 0.4f), RoundedCornerShape(16.dp)),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = IconHelper.getIconByName(app.iconName),
                contentDescription = app.name,
                tint = if (app.id == "luma_ai") Color(0xFFA855F7) else Color(0xFF38BDF8),
                modifier = Modifier.size(28.dp)
            )

            // Running indicator dot
            if (app.isRunning) {
                Box(
                    modifier = Modifier
                        .padding(4.dp)
                        .size(8.dp)
                        .clip(CircleShape)
                        .background(Color(0xFF10B981))
                        .align(Alignment.TopEnd)
                )
            }
        }

        Spacer(modifier = Modifier.height(6.dp))

        Text(
            text = app.name,
            color = Color.White,
            fontSize = 11.sp,
            fontWeight = FontWeight.Medium,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            textAlign = TextAlign.Center
        )
    }
}

@Composable
fun AppDockIconItem(
    app: VirtualApp,
    onClick: () -> Unit
) {
    Box(
        modifier = Modifier
            .size(48.dp)
            .clip(RoundedCornerShape(14.dp))
            .background(Color(0xFF1E293B))
            .border(1.dp, Color(0xFF38BDF8).copy(alpha = 0.5f), RoundedCornerShape(14.dp))
            .clickable(onClick = onClick)
            .testTag("dock_icon_${app.id}"),
        contentAlignment = Alignment.Center
    ) {
        Icon(
            imageVector = IconHelper.getIconByName(app.iconName),
            contentDescription = app.name,
            tint = if (app.id == "luma_ai") Color(0xFFA855F7) else Color(0xFF38BDF8),
            modifier = Modifier.size(24.dp)
        )
    }
}
