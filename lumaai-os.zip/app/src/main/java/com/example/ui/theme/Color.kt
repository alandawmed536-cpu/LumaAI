package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val LumaCyanPrimary = Color(0xFF38BDF8)
val LumaVioletSecondary = Color(0xFF818CF8)
val LumaEmeraldTertiary = Color(0xFF34D399)
val LumaAccentGlow = Color(0xFFA855F7)

val LumaBackgroundDark = Color(0xFF090D16)
val LumaSurfaceDark = Color(0xFF131B2E)
val LumaCardDark = Color(0xFF1E293B)
val LumaCardBorder = Color(0xFF334155)

val LumaTextPrimary = Color(0xFFF8FAFC)
val LumaTextSecondary = Color(0xFF94A3B8)
val LumaTextMuted = Color(0xFF64748B)

val LumaCyanLight = Color(0xFF0284C7)
val LumaVioletLight = Color(0xFF4F46E5)
val LumaBackgroundLight = Color(0xFFF8FAFC)
val LumaSurfaceLight = Color(0xFFFFFFFF)
