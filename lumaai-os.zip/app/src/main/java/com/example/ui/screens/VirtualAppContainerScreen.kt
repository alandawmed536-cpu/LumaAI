package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.InsertDriveFile
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Public
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Terminal
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.AppCategory
import com.example.model.VirtualApp
import com.example.ui.components.IconHelper

@Composable
fun VirtualAppContainerScreen(
    app: VirtualApp,
    onCloseApp: () -> Unit,
    onInstallApp: (VirtualApp) -> Unit,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .fillMaxSize()
            .background(Color(0xFF090D16))
    ) {
        Column(modifier = Modifier.fillMaxSize()) {
            // Virtual Window Title Bar
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Color(0xFF131B2E))
                    .padding(horizontal = 16.dp, vertical = 10.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = onCloseApp, modifier = Modifier.size(32.dp)) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Back",
                            tint = Color.White
                        )
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    Box(
                        modifier = Modifier
                            .size(28.dp)
                            .clip(RoundedCornerShape(8.dp))
                            .background(Color(0xFF1E293B)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = IconHelper.getIconByName(app.iconName),
                            contentDescription = app.name,
                            tint = Color(0xFF38BDF8),
                            modifier = Modifier.size(16.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Text(
                            text = app.name,
                            color = Color.White,
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "${app.packageName} • Sandbox Active",
                            color = Color(0xFF38BDF8),
                            fontSize = 10.sp
                        )
                    }
                }

                IconButton(onClick = onCloseApp, modifier = Modifier.testTag("close_virtual_app_window")) {
                    Icon(
                        imageVector = Icons.Default.Close,
                        contentDescription = "Close Window",
                        tint = Color.White
                    )
                }
            }

            // Virtual App Content
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f)
                    .padding(12.dp)
            ) {
                when (app.id) {
                    "luma_terminal" -> VirtualShellApp()
                    "luma_files" -> VirtualFilesApp()
                    "luma_store" -> VirtualStoreApp(onInstallApp = onInstallApp)
                    "luma_camera" -> VirtualCameraApp()
                    "luma_notes" -> VirtualNotesApp()
                    "luma_browser" -> VirtualBrowserApp()
                    "luma_phone" -> VirtualPhoneApp()
                    "luma_messages" -> VirtualMessagesApp()
                    else -> GenericVirtualAppView(app = app)
                }
            }
        }
    }
}

// 1. Virtual Terminal Shell App
@Composable
private fun VirtualShellApp() {
    var commandInput by remember { mutableStateOf("") }
    var logs by remember {
        mutableStateOf(
            listOf(
                "LumaAI OS Virtual Terminal Sandbox [Version 4.2.0]",
                "Type 'help' for available virtual shell commands.",
                "luma-os@sandbox:~# "
            )
        )
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .clip(RoundedCornerShape(16.dp))
            .background(Color(0xFF030712))
            .border(1.dp, Color(0xFF10B981).copy(alpha = 0.5f), RoundedCornerShape(16.dp))
            .padding(14.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(text = "luma-shell (SU Root)", color = Color(0xFF10B981), fontSize = 12.sp, fontWeight = FontWeight.Bold)
            Text(text = "bash 5.2", color = Color(0xFF64748B), fontSize = 10.sp)
        }

        Spacer(modifier = Modifier.height(10.dp))

        LazyColumn(
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f),
            verticalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            items(logs) { log ->
                Text(
                    text = log,
                    color = if (log.startsWith(">")) Color(0xFF38BDF8) else Color(0xFF10B981),
                    fontSize = 12.sp,
                    fontFamily = FontFamily.Monospace
                )
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(text = "$ ", color = Color(0xFF38BDF8), fontSize = 14.sp, fontFamily = FontFamily.Monospace)
            Spacer(modifier = Modifier.width(6.dp))
            OutlinedTextField(
                value = commandInput,
                onValueChange = { commandInput = it },
                placeholder = { Text("type command (e.g. luma-info, free, root)...", color = Color(0xFF64748B), fontSize = 12.sp) },
                singleLine = true,
                modifier = Modifier
                    .weight(1f)
                    .testTag("terminal_command_input"),
                shape = RoundedCornerShape(12.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = Color(0xFF10B981),
                    unfocusedBorderColor = Color(0xFF334155),
                    focusedContainerColor = Color(0xFF0F172A),
                    unfocusedContainerColor = Color(0xFF0F172A),
                    focusedTextColor = Color.White,
                    unfocusedTextColor = Color.White
                )
            )
            Spacer(modifier = Modifier.width(8.dp))
            IconButton(
                onClick = {
                    if (commandInput.isNotBlank()) {
                        val cmd = commandInput.trim()
                        val output = executeShellCommand(cmd)
                        logs = logs + "> $cmd" + output
                        commandInput = ""
                    }
                },
                modifier = Modifier.testTag("run_terminal_command")
            ) {
                Icon(imageVector = Icons.Default.PlayArrow, contentDescription = "Run", tint = Color(0xFF10B981))
            }
        }
    }
}

private fun executeShellCommand(cmd: String): List<String> {
    return when (cmd.lowercase()) {
        "help" -> listOf(
            "Available Commands:",
            "  luma-info  - Display LumaAI OS kernel info",
            "  free       - Show virtual RAM usage",
            "  root       - Query SU root sandbox state",
            "  apk list   - List installed virtual packages",
            "  clear      - Clear terminal logs"
        )
        "luma-info" -> listOf(
            "System Name: LumaAI OS",
            "Developer: LumaAI Technologies",
            "Version: v4.2 Pro AI Edition",
            "Kernel: Linux 6.1.0-Luma-ARM64"
        )
        "free" -> listOf(
            "Mem Total: 8192 MB",
            "Mem Used : 3480 MB",
            "Mem Free : 4712 MB",
            "Buffers  : 512 MB (Optimal)"
        )
        "root" -> listOf("SU Root status: ACTIVE (Luma Shield Sandbox)")
        "apk list" -> listOf(
            "pkg: com.lumaai.os.core v4.2.0",
            "pkg: com.lumaai.os.vmos v3.5.1",
            "pkg: com.lumaai.os.terminal v2.1.0",
            "pkg: com.lumaai.os.files v1.8.4"
        )
        "clear" -> listOf("luma-os@sandbox:~# ")
        else -> listOf("Command '$cmd' executed. Return code 0.")
    }
}

// 2. Virtual Files App
@Composable
private fun VirtualFilesApp() {
    val folders = listOf(
        FileItem("system/", "System Core OS Files", true, "1.4 GB"),
        FileItem("apks/", "Virtual APK Installers", true, "420 MB"),
        FileItem("storage/emulated/0/", "User Local Storage", true, "12.8 GB"),
        FileItem("luma_kernel_log.txt", "Log file", false, "12 KB"),
        FileItem("vm_config.json", "VMOS Configuration", false, "4 KB")
    )

    Column(
        modifier = Modifier
            .fillMaxSize()
            .clip(RoundedCornerShape(16.dp))
            .background(Color(0xFF131B2E))
            .padding(16.dp)
    ) {
        Text(text = "Virtual File Explorer", color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Bold)
        Text(text = "Isolated storage path: /data/luma_os/sandbox/", color = Color(0xFF38BDF8), fontSize = 11.sp)

        Spacer(modifier = Modifier.height(14.dp))

        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(folders) { file ->
                Card(
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF1E293B)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = if (file.isFolder) Icons.Default.Folder else Icons.Default.InsertDriveFile,
                                contentDescription = null,
                                tint = if (file.isFolder) Color(0xFF38BDF8) else Color(0xFF818CF8),
                                modifier = Modifier.size(24.dp)
                            )
                            Spacer(modifier = Modifier.width(12.dp))
                            Column {
                                Text(text = file.name, color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                                Text(text = file.desc, color = Color(0xFF94A3B8), fontSize = 10.sp)
                            }
                        }
                        Text(text = file.size, color = Color(0xFF38BDF8), fontSize = 11.sp)
                    }
                }
            }
        }
    }
}

private data class FileItem(val name: String, val desc: String, val isFolder: Boolean, val size: String)

// 3. Virtual Store App
@Composable
private fun VirtualStoreApp(onInstallApp: (VirtualApp) -> Unit) {
    var installedSet by remember { mutableStateOf(setOf<String>()) }

    val storeApps = listOf(
        VirtualApp("luma_game", "Neon Cyber Racer 3D", AppCategory.MEDIA, "Speed", "com.luma.game.cyber", "1.0", "3D racing game for Luma OS"),
        VirtualApp("luma_code", "Luma IDE & Compiler", AppCategory.DEVELOPER, "Code", "com.luma.dev.ide", "2.1", "Code editor for Kotlin & Python"),
        VirtualApp("luma_vpn", "Luma Shield VPN", AppCategory.UTILITIES, "Security", "com.luma.sec.vpn", "1.5", "Encrypted virtual proxy channel")
    )

    Column(
        modifier = Modifier
            .fillMaxSize()
            .clip(RoundedCornerShape(16.dp))
            .background(Color(0xFF131B2E))
            .padding(16.dp)
    ) {
        Text(text = "Luma App Store", color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Bold)
        Text(text = "Download & install virtual apps into LumaAI OS", color = Color(0xFF94A3B8), fontSize = 11.sp)

        Spacer(modifier = Modifier.height(14.dp))

        LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            items(storeApps) { app ->
                val isInstalled = app.id in installedSet
                Card(
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF1E293B)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.weight(1f)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(40.dp)
                                    .clip(RoundedCornerShape(12.dp))
                                    .background(Color(0xFF0F172A)),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = IconHelper.getIconByName(app.iconName),
                                    contentDescription = app.name,
                                    tint = Color(0xFF38BDF8),
                                    modifier = Modifier.size(22.dp)
                                )
                            }
                            Spacer(modifier = Modifier.width(12.dp))
                            Column {
                                Text(text = app.name, color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                                Text(text = app.description, color = Color(0xFF94A3B8), fontSize = 11.sp)
                            }
                        }

                        Button(
                            onClick = {
                                onInstallApp(app)
                                installedSet = installedSet + app.id
                            },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (isInstalled) Color(0xFF10B981) else Color(0xFF38BDF8)
                            ),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = if (isInstalled) Icons.Default.Check else Icons.Default.Download,
                                    contentDescription = null,
                                    tint = Color.Black,
                                    modifier = Modifier.size(14.dp)
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    text = if (isInstalled) "Installed" else "Install",
                                    color = Color.Black,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

// 4. Virtual Camera App
@Composable
private fun VirtualCameraApp() {
    var aiFilter by remember { mutableStateOf("Cyberpunk Glow") }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .clip(RoundedCornerShape(16.dp))
            .background(Color.Black)
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(text = "AI Vision Cam • $aiFilter", color = Color(0xFF38BDF8), fontSize = 14.sp, fontWeight = FontWeight.Bold)

        Spacer(modifier = Modifier.height(16.dp))

        Box(
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f)
                .clip(RoundedCornerShape(20.dp))
                .background(
                    Brush.radialGradient(
                        colors = listOf(Color(0xFF38BDF8).copy(alpha = 0.3f), Color(0xFF090D16))
                    )
                )
                .border(2.dp, Color(0xFF38BDF8).copy(alpha = 0.5f), RoundedCornerShape(20.dp)),
            contentAlignment = Alignment.Center
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Icon(imageVector = Icons.Default.CameraAlt, contentDescription = "Camera", tint = Color(0xFF38BDF8), modifier = Modifier.size(56.dp))
                Spacer(modifier = Modifier.height(8.dp))
                Text(text = "[AI Real-time Object Recognition: 99.4%]", color = Color.White, fontSize = 12.sp)
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceEvenly,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Button(
                onClick = { aiFilter = if (aiFilter == "Cyberpunk Glow") "Neural B&W" else "Cyberpunk Glow" },
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1E293B))
            ) {
                Text("Switch Filter", color = Color.White, fontSize = 12.sp)
            }

            Box(
                modifier = Modifier
                    .size(56.dp)
                    .clip(CircleShape)
                    .background(Color.White)
                    .border(3.dp, Color(0xFF38BDF8), CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Box(
                    modifier = Modifier
                        .size(44.dp)
                        .clip(CircleShape)
                        .background(Color(0xFF38BDF8))
                )
            }
        }
    }
}

// 5. Virtual Notes App
@Composable
private fun VirtualNotesApp() {
    var noteText by remember { mutableStateOf("# LumaAI OS Notes\n\n- Standalone Virtual Phone UI\n- System Name: LumaAI OS\n- Developer: LumaAI Technologies\n- Kernel v4.2 Pro AI Edition initialized successfully.") }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .clip(RoundedCornerShape(16.dp))
            .background(Color(0xFF131B2E))
            .padding(16.dp)
    ) {
        Text(text = "Luma AI Notepad", color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Bold)

        Spacer(modifier = Modifier.height(10.dp))

        OutlinedTextField(
            value = noteText,
            onValueChange = { noteText = it },
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f),
            shape = RoundedCornerShape(14.dp),
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = Color(0xFF38BDF8),
                unfocusedBorderColor = Color(0xFF334155),
                focusedContainerColor = Color(0xFF0F172A),
                unfocusedContainerColor = Color(0xFF0F172A),
                focusedTextColor = Color.White,
                unfocusedTextColor = Color.White
            )
        )
    }
}

// 6. Virtual Browser App
@Composable
private fun VirtualBrowserApp() {
    var urlText by remember { mutableStateOf("https://lumaai.os/portal") }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .clip(RoundedCornerShape(16.dp))
            .background(Color(0xFF131B2E))
            .padding(16.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(
                value = urlText,
                onValueChange = { urlText = it },
                singleLine = true,
                modifier = Modifier.weight(1f),
                shape = RoundedCornerShape(20.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = Color(0xFF38BDF8),
                    unfocusedBorderColor = Color(0xFF334155),
                    focusedContainerColor = Color(0xFF1E293B),
                    unfocusedContainerColor = Color(0xFF1E293B),
                    focusedTextColor = Color.White,
                    unfocusedTextColor = Color.White
                )
            )
            Spacer(modifier = Modifier.width(8.dp))
            IconButton(onClick = {}) {
                Icon(imageVector = Icons.Default.Refresh, contentDescription = "Reload", tint = Color(0xFF38BDF8))
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        Box(
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f)
                .clip(RoundedCornerShape(16.dp))
                .background(Color(0xFF0F172A))
                .padding(20.dp),
            contentAlignment = Alignment.Center
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Icon(imageVector = Icons.Default.Public, contentDescription = null, tint = Color(0xFF38BDF8), modifier = Modifier.size(48.dp))
                Spacer(modifier = Modifier.height(12.dp))
                Text(text = "Luma Web Sandbox Engine", color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                Text(text = "Secure isolated browsing active for $urlText", color = Color(0xFF94A3B8), fontSize = 12.sp)
            }
        }
    }
}

// 7. Virtual Phone Dialer App
@Composable
private fun VirtualPhoneApp() {
    var number by remember { mutableStateOf("") }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .clip(RoundedCornerShape(16.dp))
            .background(Color(0xFF131B2E))
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(text = number.ifEmpty { "Enter Number" }, color = Color.White, fontSize = 28.sp, fontWeight = FontWeight.Bold)

        Spacer(modifier = Modifier.height(20.dp))

        val keys = listOf("1", "2", "3", "4", "5", "6", "7", "8", "9", "*", "0", "#")
        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            keys.chunked(3).forEach { rowKeys ->
                Row(horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                    rowKeys.forEach { key ->
                        Box(
                            modifier = Modifier
                                .size(56.dp)
                                .clip(CircleShape)
                                .background(Color(0xFF1E293B))
                                .clickable { number += key },
                            contentAlignment = Alignment.Center
                        ) {
                            Text(text = key, color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        Box(
            modifier = Modifier
                .size(56.dp)
                .clip(CircleShape)
                .background(Color(0xFF10B981))
                .clickable { number = "Calling LumaAI Network..." },
            contentAlignment = Alignment.Center
        ) {
            Icon(imageVector = Icons.Default.Call, contentDescription = "Call", tint = Color.Black)
        }
    }
}

// 8. Virtual Messages App
@Composable
private fun VirtualMessagesApp() {
    var smsInput by remember { mutableStateOf("") }
    var smsList by remember { mutableStateOf(listOf("LumaAI OS: System updated to v4.2 Pro AI Edition!")) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .clip(RoundedCornerShape(16.dp))
            .background(Color(0xFF131B2E))
            .padding(16.dp)
    ) {
        Text(text = "Luma SMS Smart Messages", color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Bold)

        Spacer(modifier = Modifier.height(12.dp))

        LazyColumn(
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(smsList) { msg ->
                Card(
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF1E293B))
                ) {
                    Text(text = msg, color = Color.White, fontSize = 13.sp, modifier = Modifier.padding(12.dp))
                }
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        Row(verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(
                value = smsInput,
                onValueChange = { smsInput = it },
                placeholder = { Text("Type message...", color = Color(0xFF64748B)) },
                singleLine = true,
                modifier = Modifier.weight(1f),
                shape = RoundedCornerShape(20.dp)
            )
            Spacer(modifier = Modifier.width(8.dp))
            IconButton(onClick = {
                if (smsInput.isNotBlank()) {
                    smsList = smsList + "You: $smsInput"
                    smsInput = ""
                }
            }) {
                Icon(imageVector = Icons.AutoMirrored.Filled.Send, contentDescription = "Send", tint = Color(0xFF38BDF8))
            }
        }
    }
}

// Generic Fallback View
@Composable
private fun GenericVirtualAppView(app: VirtualApp) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .clip(RoundedCornerShape(16.dp))
            .background(Color(0xFF131B2E))
            .padding(20.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Icon(
                imageVector = IconHelper.getIconByName(app.iconName),
                contentDescription = app.name,
                tint = Color(0xFF38BDF8),
                modifier = Modifier.size(56.dp)
            )
            Spacer(modifier = Modifier.height(14.dp))
            Text(text = app.name, color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold)
            Text(text = app.packageName, color = Color(0xFF38BDF8), fontSize = 12.sp)
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = "Running inside LumaAI OS virtual environment v4.2 Pro.",
                color = Color(0xFF94A3B8),
                fontSize = 12.sp
            )
        }
    }
}
