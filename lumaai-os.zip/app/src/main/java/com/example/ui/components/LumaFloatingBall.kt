package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Phonelink
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun LumaFloatingBall(
    onHome: () -> Unit,
    onBoostRam: () -> Unit,
    onOpenAi: () -> Unit,
    onOpenVmManager: () -> Unit,
    onOpenSettings: () -> Unit,
    onToggleRoot: () -> Unit,
    modifier: Modifier = Modifier
) {
    var expanded by remember { mutableStateOf(false) }

    Box(modifier = modifier, contentAlignment = Alignment.BottomEnd) {
        // Expanded floating menu
        AnimatedVisibility(
            visible = expanded,
            enter = fadeIn() + scaleIn(),
            exit = fadeOut() + scaleOut()
        ) {
            Box(
                modifier = Modifier
                    .padding(bottom = 60.dp, end = 8.dp)
                    .shadow(16.dp, RoundedCornerShape(20.dp))
                    .clip(RoundedCornerShape(20.dp))
                    .background(
                        Brush.verticalGradient(
                            colors = listOf(
                                Color(0xFF131B2E).copy(alpha = 0.95f),
                                Color(0xFF090D16).copy(alpha = 0.95f)
                            )
                        )
                    )
                    .border(1.dp, Color(0xFF38BDF8).copy(alpha = 0.4f), RoundedCornerShape(20.dp))
                    .padding(12.dp)
            ) {
                Column(
                    horizontalAlignment = Alignment.Start,
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text(
                        text = "Luma OS Quick Tools",
                        color = Color(0xFF38BDF8),
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(bottom = 4.dp, start = 4.dp)
                    )

                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        FloatingBallActionItem(
                            icon = Icons.Default.Home,
                            label = "Home",
                            color = Color(0xFF38BDF8),
                            onClick = {
                                expanded = false
                                onHome()
                            }
                        )
                        FloatingBallActionItem(
                            icon = Icons.Default.Speed,
                            label = "Boost RAM",
                            color = Color(0xFF10B981),
                            onClick = {
                                expanded = false
                                onBoostRam()
                            }
                        )
                        FloatingBallActionItem(
                            icon = Icons.Default.AutoAwesome,
                            label = "Luma AI",
                            color = Color(0xFFA855F7),
                            onClick = {
                                expanded = false
                                onOpenAi()
                            }
                        )
                    }

                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        FloatingBallActionItem(
                            icon = Icons.Default.Phonelink,
                            label = "Subsystem",
                            color = Color(0xFF818CF8),
                            onClick = {
                                expanded = false
                                onOpenVmManager()
                            }
                        )
                        FloatingBallActionItem(
                            icon = Icons.Default.Security,
                            label = "Root Toggle",
                            color = Color(0xFFF59E0B),
                            onClick = {
                                expanded = false
                                onToggleRoot()
                            }
                        )
                        FloatingBallActionItem(
                            icon = Icons.Default.Settings,
                            label = "Settings",
                            color = Color(0xFF94A3B8),
                            onClick = {
                                expanded = false
                                onOpenSettings()
                            }
                        )
                    }
                }
            }
        }

        // Floating orb button
        Box(
            modifier = Modifier
                .size(46.dp)
                .shadow(12.dp, CircleShape)
                .clip(CircleShape)
                .background(
                    Brush.linearGradient(
                        colors = listOf(
                            Color(0xFF38BDF8),
                            Color(0xFF818CF8)
                        )
                    )
                )
                .border(2.dp, Color.White.copy(alpha = 0.8f), CircleShape)
                .clickable { expanded = !expanded }
                .testTag("floating_ball"),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = Icons.Default.AutoAwesome,
                contentDescription = "Luma Floating Menu",
                tint = Color.White,
                modifier = Modifier.size(24.dp)
            )
        }
    }
}

@Composable
private fun FloatingBallActionItem(
    icon: ImageVector,
    label: String,
    color: Color,
    onClick: () -> Unit
) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier
            .clip(RoundedCornerShape(12.dp))
            .clickable { onClick() }
            .padding(6.dp)
    ) {
        Box(
            modifier = Modifier
                .size(36.dp)
                .clip(CircleShape)
                .background(color.copy(alpha = 0.2f))
                .border(1.dp, color.copy(alpha = 0.5f), CircleShape),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = icon,
                contentDescription = label,
                tint = color,
                modifier = Modifier.size(18.dp)
            )
        }
        Spacer(modifier = Modifier.height(3.dp))
        Text(
            text = label,
            color = Color.White,
            fontSize = 9.sp,
            fontWeight = FontWeight.Medium
        )
    }
}
