package com.example.ui.components

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Chat
import androidx.compose.material.icons.filled.Android
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.DeveloperMode
import androidx.compose.material.icons.filled.EditNote
import androidx.compose.material.icons.filled.Extension
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.Memory
import androidx.compose.material.icons.filled.Phonelink
import androidx.compose.material.icons.filled.Psychology
import androidx.compose.material.icons.filled.Public
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.ShoppingBag
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.Terminal
import androidx.compose.ui.graphics.vector.ImageVector

object IconHelper {
    fun getIconByName(name: String): ImageVector {
        return when (name) {
            "Psychology" -> Icons.Default.Psychology
            "Phonelink" -> Icons.Default.Phonelink
            "Settings" -> Icons.Default.Settings
            "Terminal" -> Icons.Default.Terminal
            "Folder" -> Icons.Default.Folder
            "ShoppingBag" -> Icons.Default.ShoppingBag
            "CameraAlt" -> Icons.Default.CameraAlt
            "Public" -> Icons.Default.Public
            "EditNote" -> Icons.Default.EditNote
            "Call" -> Icons.Default.Call
            "Chat" -> Icons.AutoMirrored.Filled.Chat
            "Speed" -> Icons.Default.Speed
            "Memory" -> Icons.Default.Memory
            "Extension" -> Icons.Default.Extension
            "AutoAwesome" -> Icons.Default.AutoAwesome
            "DeveloperMode" -> Icons.Default.DeveloperMode
            else -> Icons.Default.Android
        }
    }
}
