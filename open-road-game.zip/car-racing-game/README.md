# Open Road — Free Roam Driving Game

A standalone, single-file open-world driving demo built with Three.js:

- **Procedurally shaped open-world terrain** — rolling hills, a rock line, snowy peaks, height-based ground coloring (no repeating tile textures)
- **Cinematic lighting** — gradient sky dome, directional "sun" with soft shadows, ACES Filmic tone mapping, atmospheric fog, and Unreal-style bloom post-processing
- **Day / Dusk / Night presets** — swap lighting mood live with the pills top-center (dusk & night turn the headlights on)
- **420 instanced trees + 160 rocks** scattered across the world, plus a few glowing landmark towers to navigate by
- **Physics-lite car controller** — acceleration, braking/reverse, speed-dependent steering, boost meter, and terrain-following suspension tilt (pitch/roll)
- **Mobile-ready** — on-screen steering + pedal buttons appear automatically on small screens; desktop uses WASD/arrows + Shift to boost
- **Minimap + compass + speedometer HUD**

## Run it

Just open `index.html` in a browser — no build step, no server required. It loads Three.js from a CDN.

## Connect it to your backend

Near the top of the `<script>` block:

```js
const SERVER_URL = ""; // set to "https://your-app.onrender.com"
```

Once set, the game pings your backend on start (falls back to offline/guest mode automatically if unreachable). To wire up real accounts, garage, and multiplayer using the backend from the previous step, add near `tryGuestOrAuth()`:

```js
// Login
const res = await fetch(`${SERVER_URL}/api/auth/login`, {
  method: "POST",
  headers: { "Content-Type": "application/json" },
  body: JSON.stringify({ username, password })
});
const { token, user } = await res.json();

// Multiplayer (needs the Socket.io client script)
const socket = io(SERVER_URL);
socket.emit("join_room", { roomId: "world-1", playerName: user.username, carSkin: "default" });
socket.on("opponent_state", (state) => { /* spawn/move other players' cars */ });
```

## Where to take it next

- Swap the procedural terrain for a heightmap texture if you want a hand-designed world
- Add other players as extra car instances driven by `opponent_state` socket events
- Hook the AI proxy (`/api/ai/opponent-move`) to drive a rival car around the open world
- Add collectible coins/loot pickups tied to the garage's loot box economy
- Bake road paths (darker terrain strip) if you want guided routes alongside free roam
