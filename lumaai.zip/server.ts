import express from "express";
import path from "path";
import { createServer as createViteServer } from "vite";
import { GoogleGenAI } from "@google/genai";
import dotenv from "dotenv";

dotenv.config();

const app = express();
const PORT = 3000;

app.use(express.json({ limit: "25mb" }));

// Lazy initializer for GoogleGenAI client
function getGenAI() {
  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey) {
    console.warn("GEMINI_API_KEY is missing from environment.");
  }
  return new GoogleGenAI({
    apiKey: apiKey || "",
    httpOptions: {
      headers: {
        "User-Agent": "aistudio-build",
      },
    },
  });
}

const SYSTEM_INSTRUCTION = `You are LumaAI, an intelligent, helpful, and sophisticated AI assistant modeled after modern conversational AI systems like ChatGPT.
You assist users with writing code, answering questions, writing essays, solving mathematical problems, analyzing images, and reasoning logically.

CRITICAL IDENTITY RULE (MUST FOLLOW AT ALL TIMES):
When the user asks who created you, who developed you, who built you, or who made you in ANY language (such as Kurdish: "کێ تۆی دروست کردووە؟", "کێ دروستی کردویت؟", "من دروستکەری تۆیە؟", "کێ LumaAI دروست کردووە؟", English: "who created you?", "who developed you?", "who made LumaAI?", or Arabic: "من طورك؟"), you MUST answer:
"له لايان گه شه بيده ريكي كورده وه دروست كراوم"
(If responding in English or another language, you should state that you were created by a Kurdish developer and include the exact phrase "له لايان گه شه بيده ريكي كورده وه دروست كراوم").
Never claim to be developed by OpenAI, Google, Anthropic, or Meta. You are LumaAI, created by a Kurdish developer.
Do NOT mention this creator status unless the user explicitly asks about your creator/developer.

GENERAL BEHAVIOR:
- Respond in the language used by the user (Kurdish/Sorani, English, Arabic, etc.).
- When responding in Kurdish, use natural and grammatically correct Sorani Kurdish.
- Format responses cleanly using Markdown (bold text, code blocks with language specifiers, bullet lists, tables).
- Keep answers clear, accurate, and structured.`;

// API Endpoint for Chat Generation
app.post("/api/chat", async (req, res) => {
  try {
    const { messages, model = "gemini-3.6-flash", enableWebSearch = false, isReasoning = false, image } = req.body;

    const apiKey = process.env.GEMINI_API_KEY;
    if (!apiKey) {
      // Return clear fallback message if API key isn't provided
      const lastMsg = messages?.[messages.length - 1]?.content || "";
      const isDevQuery = /کێ.*(دروست|گه‌شه‌پێده‌ر|پێشخه‌ر)|who.*(create|develop|build|make)/i.test(lastMsg);
      
      const fallbackText = isDevQuery 
        ? "له لايان گه شه بيده ريكي كورده وه دروست كراوم"
        : "سڵاو! من LumaAI م. تکایە کلیلی API زیاد بکە لە Settings > Secrets بۆ چالاککردنی تەواوی تایبەتمەندییەکان.";

      return res.json({ text: fallbackText });
    }

    const ai = getGenAI();

    // Prepare history / contents
    const contents: any[] = [];

    if (Array.isArray(messages)) {
      for (const msg of messages) {
        const role = msg.role === "user" ? "user" : "model";
        
        if (msg.image && msg === messages[messages.length - 1]) {
          // Last user message with an attached image
          const base64Data = msg.image.replace(/^data:image\/\w+;base64,/, "");
          const mimeType = msg.image.substring(msg.image.indexOf(":") + 1, msg.image.indexOf(";")) || "image/jpeg";
          
          contents.push({
            role: "user",
            parts: [
              { inlineData: { data: base64Data, mimeType } },
              { text: msg.content || "Analyze this image." }
            ]
          });
        } else {
          contents.push({
            role,
            parts: [{ text: msg.content }]
          });
        }
      }
    }

    // Config options
    const config: any = {
      systemInstruction: SYSTEM_INSTRUCTION,
    };

    if (enableWebSearch) {
      config.tools = [{ googleSearch: {} }];
    }

    const selectedModel = isReasoning ? "gemini-3.1-pro-preview" : model;

    const response = await ai.models.generateContent({
      model: selectedModel,
      contents,
      config,
    });

    const text = response.text || "No response received.";
    
    // Extract grounding search metadata if present
    const groundingChunks = response.candidates?.[0]?.groundingMetadata?.groundingChunks || [];
    const sources = groundingChunks
      .filter((chunk: any) => chunk.web)
      .map((chunk: any) => ({
        title: chunk.web.title,
        uri: chunk.web.uri,
      }));

    res.json({ text, sources });
  } catch (error: any) {
    console.error("Error in /api/chat:", error);
    res.status(500).json({ 
      error: error.message || "Failed to generate AI response",
      fallbackText: "داواکارییەکە ئەنجام نەدرا. تکایە دووبارە هەوڵبدەرەوە."
    });
  }
});

// API Endpoint for Image Generation
app.post("/api/generate-image", async (req, res) => {
  try {
    const { prompt, aspectRatio = "1:1" } = req.body;
    
    if (!prompt) {
      return res.status(400).json({ error: "Prompt is required" });
    }

    const apiKey = process.env.GEMINI_API_KEY;
    if (!apiKey) {
      return res.status(400).json({ error: "GEMINI_API_KEY environment variable is missing" });
    }

    const ai = getGenAI();

    const response = await ai.models.generateContent({
      model: "gemini-3.1-flash-lite-image",
      contents: {
        parts: [{ text: prompt }]
      },
      config: {
        imageConfig: {
          aspectRatio,
        }
      }
    });

    let imageUrl = null;
    let caption = "";

    if (response.candidates?.[0]?.content?.parts) {
      for (const part of response.candidates[0].content.parts) {
        if (part.inlineData) {
          imageUrl = `data:${part.inlineData.mimeType || "image/png"};base64,${part.inlineData.data}`;
        } else if (part.text) {
          caption += part.text;
        }
      }
    }

    if (!imageUrl) {
      return res.status(500).json({ error: "Could not generate image from prompt." });
    }

    res.json({ imageUrl, caption });
  } catch (error: any) {
    console.error("Error in /api/generate-image:", error);
    res.status(500).json({ error: error.message || "Image generation failed" });
  }
});

async function startServer() {
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`LumaAI Server running at http://0.0.0.0:${PORT}`);
  });
}

startServer();
