package com.example.data.repository

import com.example.BuildConfig
import com.example.data.api.GenerateContentRequest
import com.example.data.api.GeminiContent
import com.example.data.api.GeminiPart
import com.example.data.api.GenerationConfig
import com.example.data.api.RetrofitClient
import com.example.data.db.ChatDao
import com.example.data.db.ChatMessage
import com.example.data.db.ChatThread
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.withContext

class ChatRepository(private val chatDao: ChatDao) {

    val allThreads: Flow<List<ChatThread>> = chatDao.getAllThreads()

    fun getMessagesForThread(threadId: Long): Flow<List<ChatMessage>> {
        return chatDao.getMessagesForThread(threadId)
    }

    suspend fun createNewThread(title: String = "New Chat", modelName: String = "gemini-3.5-flash"): Long {
        val thread = ChatThread(
            title = title,
            createdAt = System.currentTimeMillis(),
            updatedAt = System.currentTimeMillis(),
            modelName = modelName
        )
        return chatDao.insertThread(thread)
    }

    suspend fun updateThreadTitle(threadId: Long, title: String) {
        chatDao.updateThreadTitle(threadId, title)
    }

    suspend fun togglePinThread(threadId: Long, currentPinned: Boolean) {
        chatDao.updateThreadPinned(threadId, !currentPinned)
    }

    suspend fun deleteThread(threadId: Long) {
        chatDao.deleteMessagesForThread(threadId)
        chatDao.deleteThread(threadId)
    }

    suspend fun clearAllHistory() {
        chatDao.clearAllMessages()
        chatDao.clearAllThreads()
    }

    suspend fun sendMessage(
        threadId: Long,
        userMessageText: String,
        selectedModel: String = "gemini-3.5-flash",
        customSystemInstruction: String? = null,
        temperature: Float = 0.7f
    ): Result<String> = withContext(Dispatchers.IO) {
        // 1. Save user message to database
        val userMsg = ChatMessage(
            threadId = threadId,
            sender = "user",
            text = userMessageText,
            timestamp = System.currentTimeMillis()
        )
        chatDao.insertMessage(userMsg)

        // 2. Fetch thread message history for context
        val history = chatDao.getMessagesListForThread(threadId)

        // 3. Update thread title if it's the first user message or still default
        val thread = chatDao.getThreadById(threadId)
        if (thread != null && (thread.title == "New Chat" || thread.title.isBlank())) {
            val generatedTitle = if (userMessageText.length > 30) {
                userMessageText.take(30) + "..."
            } else {
                userMessageText
            }
            chatDao.updateThreadTitle(threadId, generatedTitle)
        } else {
            chatDao.updateThreadTitle(threadId, thread?.title ?: "Chat")
        }

        // 4. Prepare Gemini API Request
        val apiKey = BuildConfig.GEMINI_API_KEY
        if (apiKey.isBlank() || apiKey == "MY_GEMINI_API_KEY") {
            val errorMsg = "GEMINI_API_KEY is not configured in Secrets. Please add your GEMINI_API_KEY in AI Studio Secrets panel."
            val errMessage = ChatMessage(
                threadId = threadId,
                sender = "model",
                text = errorMsg,
                timestamp = System.currentTimeMillis(),
                isError = true
            )
            chatDao.insertMessage(errMessage)
            return@withContext Result.failure(Exception(errorMsg))
        }

        // Format system instruction for LumaAI
        val baseSystemInstruction = """
            You are LumaAI, an intelligent, modern, helpful AI assistant.
            You assist users with programming, writing, math, reasoning, translation, and general questions.
            CRITICAL CREATOR DIRECTIVE: When and ONLY WHEN explicitly asked who created, built, or developed you (e.g. 'who made you', 'who created you', 'کێ تۆی دروست کردووە', ' کێ دروستی کردووی', 'من طورك', 'who developed you'), you MUST answer in Kurdish: 'لەلایەن گەشەپێدەرێکی کوردەوە دروست کراوم'.
            Do NOT mention or write this creator phrase spontaneously in general greetings or unrelated answers. Only output this response when specifically asked about your developer/creator.
            Provide clean, well-formatted answers with clear code snippets using markdown when applicable.
        """.trimIndent()

        val finalSystemInstruction = if (!customSystemInstruction.isNullOrBlank()) {
            "$baseSystemInstruction\n\nAdditional Instruction: $customSystemInstruction"
        } else {
            baseSystemInstruction
        }

        val contentsList = history.map { msg ->
            GeminiContent(
                role = if (msg.sender == "user") "user" else "model",
                parts = listOf(GeminiPart(text = msg.text))
            )
        }

        val request = GenerateContentRequest(
            contents = contentsList,
            systemInstruction = GeminiContent(
                parts = listOf(GeminiPart(text = finalSystemInstruction))
            ),
            generationConfig = GenerationConfig(temperature = temperature)
        )

        try {
            val response = RetrofitClient.service.generateContent(
                model = selectedModel,
                apiKey = apiKey,
                request = request
            )

            val replyText = response.candidates?.firstOrNull()?.content?.parts?.firstOrNull()?.text
                ?: response.error?.message
                ?: "I received an empty response. Please try again."

            if (response.error != null) {
                val errorMsg = "API Error: ${response.error.message ?: "Unknown error"}"
                val errMessage = ChatMessage(
                    threadId = threadId,
                    sender = "model",
                    text = errorMsg,
                    timestamp = System.currentTimeMillis(),
                    isError = true
                )
                chatDao.insertMessage(errMessage)
                Result.failure(Exception(errorMsg))
            } else {
                val aiMsg = ChatMessage(
                    threadId = threadId,
                    sender = "model",
                    text = replyText,
                    timestamp = System.currentTimeMillis(),
                    isError = false
                )
                chatDao.insertMessage(aiMsg)
                Result.success(replyText)
            }
        } catch (e: Exception) {
            val errorMsg = "Network / System Error: ${e.localizedMessage ?: "Failed to connect to LumaAI service"}"
            val errMessage = ChatMessage(
                threadId = threadId,
                sender = "model",
                text = errorMsg,
                timestamp = System.currentTimeMillis(),
                isError = true
            )
            chatDao.insertMessage(errMessage)
            Result.failure(e)
        }
    }
}
