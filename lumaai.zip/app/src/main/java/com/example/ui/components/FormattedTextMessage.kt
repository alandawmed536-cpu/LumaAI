package com.example.ui.components

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.ContentCopy
import androidx.compose.material.icons.outlined.Terminal
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.CodeBackground
import com.example.ui.theme.CodeHeader
import com.example.ui.theme.LumaPurple
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

@Composable
fun FormattedTextMessage(text: String) {
    val context = LocalContext.current
    val blocks = parseMarkdownBlocks(text)

    SelectionContainer {
        Column {
            blocks.forEach { block ->
                when (block) {
                    is Block.CodeBlock -> {
                        CodeBlockView(
                            lang = block.language,
                            code = block.code,
                            onCopy = {
                                copyToClipboard(context, block.code, "Code copied")
                            }
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                    }
                    is Block.TextBlock -> {
                        val annotatedText = buildAnnotatedString {
                            parseFormattedText(block.content, this)
                        }
                        Text(
                            text = annotatedText,
                            style = MaterialTheme.typography.bodyLarge.copy(
                                color = TextPrimary,
                                fontSize = 15.sp,
                                lineHeight = 22.sp
                            ),
                            modifier = Modifier.padding(vertical = 2.dp)
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun CodeBlockView(
    lang: String,
    code: String,
    onCopy: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 6.dp)
            .clip(RoundedCornerShape(8.dp))
            .background(CodeBackground)
            .border(1.dp, MaterialTheme.colorScheme.outline, RoundedCornerShape(8.dp))
    ) {
        // Header
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(CodeHeader)
                .padding(horizontal = 12.dp, vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = Icons.Outlined.Terminal,
                contentDescription = null,
                tint = LumaPurple,
                modifier = Modifier.padding(end = 6.dp)
            )
            Text(
                text = if (lang.isNotBlank()) lang.lowercase() else "code",
                style = MaterialTheme.typography.labelMedium.copy(
                    color = TextSecondary,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold
                )
            )
            Spacer(modifier = Modifier.weight(1f))
            IconButton(
                onClick = onCopy,
                modifier = Modifier.padding(0.dp)
            ) {
                Icon(
                    imageVector = Icons.Outlined.ContentCopy,
                    contentDescription = "Copy code",
                    tint = TextMuted
                )
            }
        }

        // Code Body
        Text(
            text = code,
            style = MaterialTheme.typography.bodyMedium.copy(
                fontFamily = FontFamily.Monospace,
                fontSize = 13.sp,
                color = TextPrimary,
                lineHeight = 18.sp
            ),
            modifier = Modifier.padding(12.dp)
        )
    }
}

private sealed class Block {
    data class TextBlock(val content: String) : Block()
    data class CodeBlock(val language: String, val code: String) : Block()
}

private fun parseMarkdownBlocks(rawText: String): List<Block> {
    val blocks = mutableListOf<Block>()
    val lines = rawText.split("\n")
    var inCode = false
    var currentLang = ""
    val codeBuilder = StringBuilder()
    val textBuilder = StringBuilder()

    for (line in lines) {
        if (line.trimStart().startsWith("```")) {
            if (inCode) {
                // End code block
                blocks.add(Block.CodeBlock(currentLang, codeBuilder.toString().trimEnd()))
                codeBuilder.clear()
                inCode = false
            } else {
                // Start code block
                if (textBuilder.isNotEmpty()) {
                    blocks.add(Block.TextBlock(textBuilder.toString().trimEnd()))
                    textBuilder.clear()
                }
                inCode = true
                currentLang = line.trimStart().removePrefix("```").trim()
            }
        } else {
            if (inCode) {
                codeBuilder.append(line).append("\n")
            } else {
                textBuilder.append(line).append("\n")
            }
        }
    }

    if (inCode && codeBuilder.isNotEmpty()) {
        blocks.add(Block.CodeBlock(currentLang, codeBuilder.toString().trimEnd()))
    } else if (textBuilder.isNotEmpty()) {
        blocks.add(Block.TextBlock(textBuilder.toString().trimEnd()))
    }

    return if (blocks.isEmpty()) listOf(Block.TextBlock(rawText)) else blocks
}

private fun parseFormattedText(text: String, builder: androidx.compose.ui.text.AnnotatedString.Builder) {
    // Simple markdown inline bolding **text** handling
    val parts = text.split("**")
    for (i in parts.indices) {
        if (i % 2 == 1) { // Odd index = bold
            builder.withStyle(SpanStyle(fontWeight = FontWeight.Bold, color = Color.White)) {
                append(parts[i])
            }
        } else {
            builder.append(parts[i])
        }
    }
}

fun copyToClipboard(context: Context, text: String, label: String = "Copied") {
    val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
    val clip = ClipData.newPlainText("LumaAI", text)
    clipboard.setPrimaryClip(clip)
    Toast.makeText(context, label, Toast.LENGTH_SHORT).show()
}
