package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// LumaAI Modern Dark Aesthetic
val DarkCanvas = Color(0xFF09090B)
val DarkSurface = Color(0xFF141417)
val DarkSurfaceVariant = Color(0xFF1F1F23)
val DarkUserBubble = Color(0xFF27272A)
val DarkAiBubble = Color(0xFF141418)
val DarkBorder = Color(0xFF2E2E33)

val LumaPurple = Color(0xFFA855F7)
val LumaViolet = Color(0xFF8B5CF6)
val LumaBlue = Color(0xFF3B82F6)
val LumaGreen = Color(0xFF10B981)

val TextPrimary = Color(0xFFF4F4F5)
val TextSecondary = Color(0xFFA1A1AA)
val TextMuted = Color(0xFF71717A)

val CodeBackground = Color(0xFF0D0D11)
val CodeHeader = Color(0xFF1A1A22)
