package com.example.ui.components

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.AutoAwesome
import androidx.compose.material.icons.outlined.Code
import androidx.compose.material.icons.outlined.Edit
import androidx.compose.material.icons.outlined.Lightbulb
import androidx.compose.material.icons.outlined.Translate
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.ui.theme.DarkSurface
import com.example.ui.theme.DarkSurfaceVariant
import com.example.ui.theme.LumaBlue
import com.example.ui.theme.LumaPurple
import com.example.ui.theme.LumaViolet
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

data class PromptPreset(
    val title: String,
    val subtitle: String,
    val promptText: String,
    val icon: ImageVector,
    val accentColor: Color
)

@Composable
fun EmptyChatLanding(
    onSelectPrompt: (String) -> Unit
) {
    val presets = listOf(
        PromptPreset(
            title = "Coding Assistant",
            subtitle = "Build Kotlin Jetpack Compose app or debug code",
            promptText = "Write a Kotlin Jetpack Compose UI component with clean state management and modern design.",
            icon = Icons.Outlined.Code,
            accentColor = LumaPurple
        ),
        PromptPreset(
            title = "Kurdish Translator",
            subtitle = "Accurate Kurdish (Sorani/Badini) & English translation",
            promptText = "ژیریا دەستکرد LumaAI چۆن کار دەکات؟ بۆم ڕوون بکەرەوە به کوردییه‌کی زۆر ڕوان و جوان.",
            icon = Icons.Outlined.Translate,
            accentColor = LumaBlue
        ),
        PromptPreset(
            title = "Creative Writing",
            subtitle = "Draft essays, articles, or story ideas",
            promptText = "Draft a compelling blog post about how AI is shaping the future of mobile software development.",
            icon = Icons.Outlined.Edit,
            accentColor = LumaViolet
        ),
        PromptPreset(
            title = "Problem Solving",
            subtitle = "Step-by-step logic, math & tech analysis",
            promptText = "Explain quantum computing in simple terms with step-by-step analogies.",
            icon = Icons.Outlined.Lightbulb,
            accentColor = Color(0xFFF59E0B)
        )
    )

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 20.dp, vertical = 24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Spacer(modifier = Modifier.height(20.dp))

        // LumaAI Glowing Header Icon
        Box(
            modifier = Modifier
                .size(72.dp)
                .clip(CircleShape)
                .background(
                    Brush.radialGradient(
                        colors = listOf(LumaPurple.copy(alpha = 0.4f), Color.Transparent)
                    )
                )
                .border(2.dp, LumaPurple, CircleShape)
                .padding(4.dp),
            contentAlignment = Alignment.Center
        ) {
            Image(
                painter = painterResource(id = R.drawable.ic_luma_logo_1785056485096),
                contentDescription = "LumaAI Logo",
                modifier = Modifier
                    .size(56.dp)
                    .clip(CircleShape)
            )
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Title
        Text(
            text = "LumaAI",
            style = MaterialTheme.typography.headlineLarge.copy(
                fontWeight = FontWeight.ExtraBold,
                fontSize = 28.sp,
                color = TextPrimary
            )
        )

        Text(
            text = "How can LumaAI help you today?",
            style = MaterialTheme.typography.bodyLarge.copy(
                color = TextSecondary,
                fontSize = 16.sp
            ),
            modifier = Modifier.padding(top = 6.dp, bottom = 32.dp),
            textAlign = TextAlign.Center
        )

        // Preset Cards Grid
        Column(
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            presets.chunked(2).forEach { rowPresets ->
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    rowPresets.forEach { preset ->
                        PresetCard(
                            preset = preset,
                            onClick = { onSelectPrompt(preset.promptText) },
                            modifier = Modifier.weight(1f)
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(32.dp))

        Row(
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = Icons.Outlined.AutoAwesome,
                contentDescription = null,
                tint = TextMuted,
                modifier = Modifier.size(16.dp)
            )
            Spacer(modifier = Modifier.width(6.dp))
            Text(
                text = "Powered by Gemini 3.5 Flash & Pro Models",
                style = MaterialTheme.typography.labelMedium.copy(
                    color = TextMuted,
                    fontSize = 12.sp
                )
            )
        }
    }
}

@Composable
private fun PresetCard(
    preset: PromptPreset,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .clip(RoundedCornerShape(16.dp))
            .background(DarkSurface)
            .border(1.dp, MaterialTheme.colorScheme.outline, RoundedCornerShape(16.dp))
            .clickable { onClick() }
            .padding(14.dp)
    ) {
        Box(
            modifier = Modifier
                .size(36.dp)
                .clip(CircleShape)
                .background(preset.accentColor.copy(alpha = 0.15f)),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = preset.icon,
                contentDescription = preset.title,
                tint = preset.accentColor,
                modifier = Modifier.size(20.dp)
            )
        }

        Spacer(modifier = Modifier.height(10.dp))

        Text(
            text = preset.title,
            style = MaterialTheme.typography.titleMedium.copy(
                fontWeight = FontWeight.Bold,
                color = TextPrimary,
                fontSize = 14.sp
            )
        )

        Text(
            text = preset.subtitle,
            style = MaterialTheme.typography.bodySmall.copy(
                color = TextMuted,
                fontSize = 12.sp,
                lineHeight = 16.sp
            ),
            modifier = Modifier.padding(top = 4.dp),
            maxLines = 2
        )
    }
}
