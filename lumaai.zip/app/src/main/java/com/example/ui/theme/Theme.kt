package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val LumaDarkColorScheme = darkColorScheme(
    primary = LumaPurple,
    onPrimary = Color.White,
    primaryContainer = LumaViolet,
    onPrimaryContainer = Color.White,
    secondary = LumaBlue,
    onSecondary = Color.White,
    tertiary = LumaGreen,
    background = DarkCanvas,
    onBackground = TextPrimary,
    surface = DarkSurface,
    onSurface = TextPrimary,
    surfaceVariant = DarkSurfaceVariant,
    onSurfaceVariant = TextSecondary,
    outline = DarkBorder,
    outlineVariant = DarkBorder
)

@Composable
fun LumaAITheme(
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = LumaDarkColorScheme,
        typography = Typography,
        content = content
    )
}
