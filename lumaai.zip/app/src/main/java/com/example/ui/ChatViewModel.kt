package com.example.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.db.AppDatabase
import com.example.data.db.ChatMessage
import com.example.data.db.ChatThread
import com.example.data.repository.ChatRepository
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class ChatViewModel(application: Application) : AndroidViewModel(application) {

    private val repository: ChatRepository

    val allThreads: StateFlow<List<ChatThread>>

    private val _activeThreadId = MutableStateFlow<Long?>(null)
    val activeThreadId: StateFlow<Long?> = _activeThreadId.asStateFlow()

    private val _isLoading = MutableStateFlow(false)
    val isLoading: StateFlow<Boolean> = _isLoading.asStateFlow()

    private val _selectedModel = MutableStateFlow("gemini-3.5-flash")
    val selectedModel: StateFlow<String> = _selectedModel.asStateFlow()

    private val _customSystemInstruction = MutableStateFlow("")
    val customSystemInstruction: StateFlow<String> = _customSystemInstruction.asStateFlow()

    private val _temperature = MutableStateFlow(0.7f)
    val temperature: StateFlow<Float> = _temperature.asStateFlow()

    @OptIn(ExperimentalCoroutinesApi::class)
    val currentMessages: StateFlow<List<ChatMessage>>

    init {
        val database = AppDatabase.getInstance(application)
        repository = ChatRepository(database.chatDao())

        allThreads = repository.allThreads
            .stateIn(
                scope = viewModelScope,
                started = SharingStarted.WhileSubscribed(5000),
                initialValue = emptyList()
            )

        currentMessages = _activeThreadId
            .flatMapLatest { id ->
                if (id != null) {
                    repository.getMessagesForThread(id)
                } else {
                    flowOf(emptyList())
                }
            }
            .stateIn(
                scope = viewModelScope,
                started = SharingStarted.WhileSubscribed(5000),
                initialValue = emptyList()
            )

        // Automatically select or create initial thread when app starts
        viewModelScope.launch {
            repository.allThreads.collect { threads ->
                if (_activeThreadId.value == null) {
                    if (threads.isNotEmpty()) {
                        _activeThreadId.value = threads.first().id
                    } else {
                        val newId = repository.createNewThread("New Chat", _selectedModel.value)
                        _activeThreadId.value = newId
                    }
                }
            }
        }
    }

    fun selectThread(threadId: Long) {
        _activeThreadId.value = threadId
    }

    fun createNewThread() {
        viewModelScope.launch {
            val newId = repository.createNewThread("New Chat", _selectedModel.value)
            _activeThreadId.value = newId
        }
    }

    fun updateThreadTitle(threadId: Long, newTitle: String) {
        viewModelScope.launch {
            repository.updateThreadTitle(threadId, newTitle)
        }
    }

    fun togglePinThread(threadId: Long, currentPinned: Boolean) {
        viewModelScope.launch {
            repository.togglePinThread(threadId, currentPinned)
        }
    }

    fun deleteThread(threadId: Long) {
        viewModelScope.launch {
            repository.deleteThread(threadId)
            if (_activeThreadId.value == threadId) {
                val remaining = allThreads.value.filter { it.id != threadId }
                if (remaining.isNotEmpty()) {
                    _activeThreadId.value = remaining.first().id
                } else {
                    val newId = repository.createNewThread("New Chat", _selectedModel.value)
                    _activeThreadId.value = newId
                }
            }
        }
    }

    fun clearAllHistory() {
        viewModelScope.launch {
            repository.clearAllHistory()
            val newId = repository.createNewThread("New Chat", _selectedModel.value)
            _activeThreadId.value = newId
        }
    }

    fun updateSettings(modelName: String, systemInstruction: String, temp: Float) {
        _selectedModel.value = modelName
        _customSystemInstruction.value = systemInstruction
        _temperature.value = temp
    }

    fun sendMessage(promptText: String) {
        if (promptText.isBlank() || _isLoading.value) return

        viewModelScope.launch {
            var threadId = _activeThreadId.value
            if (threadId == null) {
                threadId = repository.createNewThread("New Chat", _selectedModel.value)
                _activeThreadId.value = threadId
            }

            _isLoading.value = true

            repository.sendMessage(
                threadId = threadId,
                userMessageText = promptText.trim(),
                selectedModel = _selectedModel.value,
                customSystemInstruction = _customSystemInstruction.value,
                temperature = _temperature.value
            )

            _isLoading.value = false
        }
    }

    fun retryLastMessage() {
        val messages = currentMessages.value
        val lastUserMessage = messages.lastOrNull { it.sender == "user" }
        if (lastUserMessage != null && !_isLoading.value) {
            sendMessage(lastUserMessage.text)
        }
    }
}
