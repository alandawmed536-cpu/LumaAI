import React, { useState, useRef, useEffect } from "react";
import { Send, Image as ImageIcon, Mic, MicOff, Globe, Brain, X, StopCircle } from "lucide-react";
import { AIModelMode, AppLanguage } from "../types";

interface ChatInputProps {
  onSendMessage: (content: string, image?: string) => void;
  isLoading: boolean;
  onStop?: () => void;
  currentMode: AIModelMode;
  onToggleMode: (mode: AIModelMode) => void;
  language: AppLanguage;
}

export const ChatInput: React.FC<ChatInputProps> = ({
  onSendMessage,
  isLoading,
  onStop,
  currentMode,
  onToggleMode,
  language,
}) => {
  const [prompt, setPrompt] = useState("");
  const [imagePreview, setImagePreview] = useState<string | null>(null);
  const [isListening, setIsListening] = useState(false);
  const textareaRef = useRef<HTMLTextAreaElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const isKurdish = language === "ku";

  // Auto-resize textarea
  useEffect(() => {
    if (textareaRef.current) {
      textareaRef.current.style.height = "auto";
      textareaRef.current.style.height = `${Math.min(textareaRef.current.scrollHeight, 200)}px`;
    }
  }, [prompt]);

  const handleKeyDown = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      handleSubmit();
    }
  };

  const handleSubmit = () => {
    if ((prompt.trim() || imagePreview) && !isLoading) {
      onSendMessage(prompt.trim(), imagePreview || undefined);
      setPrompt("");
      setImagePreview(null);
      if (textareaRef.current) {
        textareaRef.current.style.height = "auto";
      }
    }
  };

  const handleImageSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setImagePreview(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const toggleMic = () => {
    if ("webkitSpeechRecognition" in window || "SpeechRecognition" in window) {
      const SpeechRecognition =
        (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
      
      if (isListening) {
        setIsListening(false);
      } else {
        const recognition = new SpeechRecognition();
        recognition.continuous = false;
        recognition.interimResults = false;
        recognition.lang = language === "ku" ? "ckb" : language === "ar" ? "ar-SA" : "en-US";

        recognition.onstart = () => setIsListening(true);
        recognition.onresult = (event: any) => {
          const transcript = event.results[0][0].transcript;
          setPrompt((prev) => (prev ? `${prev} ${transcript}` : transcript));
          setIsListening(false);
        };
        recognition.onerror = () => setIsListening(false);
        recognition.onend = () => setIsListening(false);

        recognition.start();
      }
    } else {
      alert("مایکڕۆفۆن لەم وێبگەڕەدا پاڵپشتی ناکرێت.");
    }
  };

  return (
    <div className="w-full max-w-4xl mx-auto px-4 pb-4 md:pb-6 pt-2">
      <div className="relative rounded-2xl bg-zinc-950 border border-zinc-800 shadow-2xl focus-within:border-zinc-700/90 transition-all p-3">
        {/* Attached Image Preview */}
        {imagePreview && (
          <div className="relative inline-block mb-3">
            <img
              src={imagePreview}
              alt="Attachment"
              className="w-20 h-20 object-cover rounded-xl border border-zinc-700 shadow-md"
            />
            <button
              onClick={() => setImagePreview(null)}
              className="absolute -top-2 -right-2 p-1 rounded-full bg-zinc-800 text-zinc-300 hover:text-white border border-zinc-600 cursor-pointer"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          </div>
        )}

        {/* Text Input Area */}
        <textarea
          ref={textareaRef}
          value={prompt}
          onChange={(e) => setPrompt(e.target.value)}
          onKeyDown={handleKeyDown}
          placeholder={
            isKurdish
              ? "نامەیەک بنووسە یان بپرسە... (Press Enter to send)"
              : "Message LumaAI... (Shift+Enter for new line)"
          }
          rows={1}
          className="w-full bg-transparent text-white placeholder-zinc-500 text-sm md:text-base focus:outline-none resize-none px-2 py-1 max-h-48 scrollbar-thin scrollbar-thumb-zinc-700"
        />

        {/* Bottom Bar Tools & Controls */}
        <div className="flex items-center justify-between pt-2 mt-1 border-t border-zinc-900/80">
          {/* Mode Quick Toggles */}
          <div className="flex items-center gap-1.5 flex-wrap">
            <button
              onClick={() =>
                onToggleMode(currentMode === "search" ? "flash" : "search")
              }
              className={`flex items-center gap-1.5 px-2.5 py-1 rounded-lg text-xs font-medium border transition-all cursor-pointer ${
                currentMode === "search"
                  ? "bg-blue-500/20 text-blue-400 border-blue-500/40"
                  : "bg-zinc-900/90 text-zinc-400 border-zinc-800 hover:border-zinc-700"
              }`}
            >
              <Globe className="w-3.5 h-3.5" />
              <span>{isKurdish ? "گەڕان لە وێب" : "Search"}</span>
            </button>

            <button
              onClick={() =>
                onToggleMode(currentMode === "reason" ? "flash" : "reason")
              }
              className={`flex items-center gap-1.5 px-2.5 py-1 rounded-lg text-xs font-medium border transition-all cursor-pointer ${
                currentMode === "reason"
                  ? "bg-purple-500/20 text-purple-400 border-purple-500/40"
                  : "bg-zinc-900/90 text-zinc-400 border-zinc-800 hover:border-zinc-700"
              }`}
            >
              <Brain className="w-3.5 h-3.5" />
              <span>{isKurdish ? "شیکاری قوڵ" : "Reason"}</span>
            </button>

            <button
              onClick={() =>
                onToggleMode(currentMode === "image" ? "flash" : "image")
              }
              className={`flex items-center gap-1.5 px-2.5 py-1 rounded-lg text-xs font-medium border transition-all cursor-pointer ${
                currentMode === "image"
                  ? "bg-amber-500/20 text-amber-400 border-amber-500/40"
                  : "bg-zinc-900/90 text-zinc-400 border-zinc-800 hover:border-zinc-700"
              }`}
            >
              <ImageIcon className="w-3.5 h-3.5" />
              <span>{isKurdish ? "وێنە" : "Image"}</span>
            </button>
          </div>

          {/* Action Buttons: Image Attachment, Mic, Send */}
          <div className="flex items-center gap-1.5 shrink-0">
            <input
              type="file"
              ref={fileInputRef}
              accept="image/*"
              className="hidden"
              onChange={handleImageSelect}
            />
            <button
              type="button"
              onClick={() => fileInputRef.current?.click()}
              className="p-2 rounded-xl text-zinc-400 hover:text-white hover:bg-zinc-900 transition-colors cursor-pointer"
              title="بارکردنی وێنە (Upload image)"
            >
              <ImageIcon className="w-4 h-4" />
            </button>

            <button
              type="button"
              onClick={toggleMic}
              className={`p-2 rounded-xl transition-colors cursor-pointer ${
                isListening
                  ? "bg-red-500/20 text-red-400 animate-pulse border border-red-500/40"
                  : "text-zinc-400 hover:text-white hover:bg-zinc-900"
              }`}
              title="تۆمارکردنی دەنگ (Voice input)"
            >
              {isListening ? <MicOff className="w-4 h-4" /> : <Mic className="w-4 h-4" />}
            </button>

            {isLoading ? (
              <button
                onClick={onStop}
                className="p-2.5 rounded-xl bg-red-600/20 text-red-400 hover:bg-red-600/30 border border-red-500/40 transition-all cursor-pointer"
                title="وەستاندن (Stop generation)"
              >
                <StopCircle className="w-4 h-4" />
              </button>
            ) : (
              <button
                onClick={handleSubmit}
                disabled={!prompt.trim() && !imagePreview}
                className={`p-2.5 rounded-xl transition-all cursor-pointer flex items-center justify-center ${
                  prompt.trim() || imagePreview
                    ? "bg-emerald-600 hover:bg-emerald-500 text-white shadow-lg shadow-emerald-950"
                    : "bg-zinc-800 text-zinc-500 cursor-not-allowed"
                }`}
              >
                <Send className="w-4 h-4" />
              </button>
            )}
          </div>
        </div>
      </div>

      <p className="text-[11px] text-zinc-500 text-center mt-2.5 font-medium">
        LumaAI دەکرێت هەڵە بکات. زانیارییە گرنگەکان بپشکنەوە.
      </p>
    </div>
  );
};
