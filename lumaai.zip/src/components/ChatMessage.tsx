import React, { useState } from "react";
import ReactMarkdown from "react-markdown";
import remarkGfm from "remark-gfm";
import { ChatMessage as ChatMessageType, GroundingSource } from "../types";
import { Sparkles, User, Copy, Check, Volume2, VolumeX, RotateCcw, Edit2, ExternalLink, Globe } from "lucide-react";

interface ChatMessageProps {
  message: ChatMessageType;
  onRegenerate?: () => void;
  onEdit?: (newContent: string) => void;
  accentColor: string;
}

export const ChatMessage: React.FC<ChatMessageProps> = ({
  message,
  onRegenerate,
  onEdit,
}) => {
  const [copied, setCopied] = useState(false);
  const [isSpeaking, setIsSpeaking] = useState(false);
  const [isEditing, setIsEditing] = useState(false);
  const [editText, setEditText] = useState(message.content);

  const isUser = message.role === "user";

  const handleCopy = () => {
    navigator.clipboard.writeText(message.content);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleSpeak = () => {
    if ("speechSynthesis" in window) {
      if (isSpeaking) {
        window.speechSynthesis.cancel();
        setIsSpeaking(false);
      } else {
        window.speechSynthesis.cancel();
        const utterance = new SpeechSynthesisUtterance(message.content);
        utterance.onend = () => setIsSpeaking(false);
        utterance.onerror = () => setIsSpeaking(false);
        setIsSpeaking(true);
        window.speechSynthesis.speak(utterance);
      }
    }
  };

  const handleSaveEdit = () => {
    if (onEdit && editText.trim()) {
      onEdit(editText.trim());
      setIsEditing(false);
    }
  };

  return (
    <div
      className={`w-full py-6 px-4 md:px-6 transition-colors border-b border-zinc-900/60 ${
        isUser ? "bg-transparent" : "bg-zinc-950/80"
      }`}
    >
      <div className="max-w-4xl mx-auto flex gap-4 md:gap-6 items-start">
        {/* Avatar */}
        <div className="shrink-0 mt-0.5">
          {isUser ? (
            <div className="w-8 h-8 rounded-full bg-zinc-800 border border-zinc-700 flex items-center justify-center text-zinc-200 shadow-md">
              <User className="w-4 h-4" />
            </div>
          ) : (
            <div className="w-8 h-8 rounded-full bg-gradient-to-tr from-emerald-600 to-teal-400 p-0.5 shadow-md flex items-center justify-center">
              <div className="w-full h-full bg-zinc-950 rounded-full flex items-center justify-center">
                <Sparkles className="w-4 h-4 text-emerald-400" />
              </div>
            </div>
          )}
        </div>

        {/* Content Body */}
        <div className="flex-1 min-w-0 space-y-3">
          {/* Header Name & Timestamp */}
          <div className="flex items-center justify-between">
            <span className="text-sm font-semibold text-zinc-300 flex items-center gap-2">
              {isUser ? "You" : "LumaAI"}
              {!isUser && message.modelUsed && (
                <span className="text-[10px] uppercase font-mono px-1.5 py-0.5 rounded bg-zinc-900 border border-zinc-800 text-zinc-400">
                  {message.modelUsed}
                </span>
              )}
            </span>
            <span className="text-[11px] text-zinc-500 font-mono">
              {new Date(message.timestamp).toLocaleTimeString([], {
                hour: "2-digit",
                minute: "2-digit",
              })}
            </span>
          </div>

          {/* Attached Image if any */}
          {message.image && (
            <div className="my-2 max-w-sm rounded-2xl overflow-hidden border border-zinc-800 shadow-xl bg-zinc-900">
              <img
                src={message.image}
                alt="Uploaded or Generated visual"
                className="w-full h-auto object-cover max-h-96"
                referrerPolicy="no-referrer"
              />
            </div>
          )}

          {/* Text Message or Edit Mode */}
          {isEditing ? (
            <div className="space-y-2 mt-2">
              <textarea
                value={editText}
                onChange={(e) => setEditText(e.target.value)}
                className="w-full p-3 rounded-xl bg-zinc-900 border border-zinc-700 text-white focus:outline-none focus:border-emerald-500 text-sm font-sans resize-none min-h-[100px]"
              />
              <div className="flex items-center justify-end gap-2">
                <button
                  onClick={() => setIsEditing(false)}
                  className="px-3 py-1.5 rounded-lg text-xs font-medium bg-zinc-800 text-zinc-300 hover:bg-zinc-700 cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  onClick={handleSaveEdit}
                  className="px-3 py-1.5 rounded-lg text-xs font-medium bg-emerald-600 text-white hover:bg-emerald-500 cursor-pointer"
                >
                  Save & Submit
                </button>
              </div>
            </div>
          ) : (
            <div className="text-zinc-200 text-sm md:text-base leading-relaxed space-y-3 break-words font-sans selection:bg-emerald-500/30">
              <ReactMarkdown
                remarkPlugins={[remarkGfm]}
                components={{
                  code({ node, inline, className, children, ...props }: any) {
                    const match = /language-(\w+)/.exec(className || "");
                    const codeString = String(children).replace(/\n$/, "");

                    if (!inline && match) {
                      return (
                        <div className="my-4 rounded-xl overflow-hidden border border-zinc-800 bg-zinc-950 shadow-2xl">
                          <div className="flex items-center justify-between px-4 py-2 bg-zinc-900/90 border-b border-zinc-800/80 text-xs font-mono text-zinc-400">
                            <span className="uppercase font-semibold tracking-wider text-emerald-400">
                              {match[1]}
                            </span>
                            <button
                              onClick={() => {
                                navigator.clipboard.writeText(codeString);
                              }}
                              className="flex items-center gap-1.5 hover:text-white transition-colors cursor-pointer"
                            >
                              <Copy className="w-3.5 h-3.5" />
                              <span>Copy code</span>
                            </button>
                          </div>
                          <pre className="p-4 text-xs md:text-sm font-mono text-zinc-200 overflow-x-auto leading-relaxed">
                            <code>{codeString}</code>
                          </pre>
                        </div>
                      );
                    }
                    return (
                      <code
                        className="bg-zinc-800/80 text-emerald-300 px-1.5 py-0.5 rounded text-xs font-mono border border-zinc-700/50"
                        {...props}
                      >
                        {children}
                      </code>
                    );
                  },
                  p: ({ children }) => <p className="mb-2 last:mb-0 leading-relaxed">{children}</p>,
                  ul: ({ children }) => <ul className="list-disc pl-6 my-2 space-y-1 text-zinc-300">{children}</ul>,
                  ol: ({ children }) => <ol className="list-decimal pl-6 my-2 space-y-1 text-zinc-300">{children}</ol>,
                  blockquote: ({ children }) => (
                    <blockquote className="border-l-4 border-emerald-500/70 pl-4 py-1 my-2 text-zinc-400 italic bg-zinc-900/50 rounded-r-lg">
                      {children}
                    </blockquote>
                  ),
                  table: ({ children }) => (
                    <div className="overflow-x-auto my-4 rounded-xl border border-zinc-800">
                      <table className="w-full text-left border-collapse text-xs md:text-sm">{children}</table>
                    </div>
                  ),
                  th: ({ children }) => (
                    <th className="bg-zinc-900 p-2.5 font-semibold border-b border-zinc-800 text-zinc-200">{children}</th>
                  ),
                  td: ({ children }) => <td className="p-2.5 border-b border-zinc-800/50 text-zinc-300">{children}</td>,
                }}
              >
                {message.content}
              </ReactMarkdown>
            </div>
          )}

          {/* Grounding Sources Pills */}
          {message.sources && message.sources.length > 0 && (
            <div className="mt-4 pt-3 border-t border-zinc-900">
              <div className="flex items-center gap-1.5 text-xs text-zinc-400 mb-2 font-medium">
                <Globe className="w-3.5 h-3.5 text-blue-400" />
                <span>سەرچاوەکانی گەڕان (Sources):</span>
              </div>
              <div className="flex flex-wrap gap-2">
                {message.sources.map((src: GroundingSource, i: number) => (
                  <a
                    key={i}
                    href={src.uri}
                    target="_blank"
                    rel="noreferrer"
                    className="flex items-center gap-1.5 text-xs px-2.5 py-1 rounded-lg bg-zinc-900 border border-zinc-800 hover:border-zinc-700 text-blue-400 hover:text-blue-300 transition-all max-w-xs truncate"
                  >
                    <ExternalLink className="w-3 h-3 shrink-0" />
                    <span className="truncate">{src.title || src.uri}</span>
                  </a>
                ))}
              </div>
            </div>
          )}

          {/* Action Toolbar */}
          {!isEditing && (
            <div className="flex items-center gap-3 pt-2 text-zinc-500">
              <button
                onClick={handleCopy}
                className="hover:text-zinc-200 transition-colors p-1.5 rounded-lg hover:bg-zinc-900 cursor-pointer"
                title="کۆپیکردن (Copy)"
              >
                {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
              </button>

              <button
                onClick={handleSpeak}
                className="hover:text-zinc-200 transition-colors p-1.5 rounded-lg hover:bg-zinc-900 cursor-pointer"
                title="خوێندنەوەی بە دەنگ (Read aloud)"
              >
                {isSpeaking ? <VolumeX className="w-3.5 h-3.5 text-amber-400" /> : <Volume2 className="w-3.5 h-3.5" />}
              </button>

              {isUser && onEdit && (
                <button
                  onClick={() => setIsEditing(true)}
                  className="hover:text-zinc-200 transition-colors p-1.5 rounded-lg hover:bg-zinc-900 cursor-pointer"
                  title="دەستکاری (Edit)"
                >
                  <Edit2 className="w-3.5 h-3.5" />
                </button>
              )}

              {!isUser && onRegenerate && (
                <button
                  onClick={onRegenerate}
                  className="hover:text-zinc-200 transition-colors p-1.5 rounded-lg hover:bg-zinc-900 cursor-pointer flex items-center gap-1 text-xs"
                  title="دووبارە دروستکردنەوە (Regenerate)"
                >
                  <RotateCcw className="w-3.5 h-3.5" />
                </button>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
