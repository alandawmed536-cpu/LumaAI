import React from "react";
import { UserSettings, AccentColor, AppLanguage } from "../types";
import { X, Volume2, Globe, Trash2, Shield, Info, Check } from "lucide-react";

interface SettingsModalProps {
  isOpen: boolean;
  onClose: () => void;
  settings: UserSettings;
  onUpdateSettings: (newSettings: Partial<UserSettings>) => void;
  onClearAllChats: () => void;
}

export const SettingsModal: React.FC<SettingsModalProps> = ({
  isOpen,
  onClose,
  settings,
  onUpdateSettings,
  onClearAllChats,
}) => {
  if (!isOpen) return null;

  const isKurdish = settings.language === "ku";

  const languages: { code: AppLanguage; label: string }[] = [
    { code: "ku", label: "کوردی (Kurdish)" },
    { code: "en", label: "English" },
    { code: "ar", label: "العربية (Arabic)" },
  ];

  const colors: { code: AccentColor; bg: string; name: string }[] = [
    { code: "emerald", bg: "bg-emerald-500", name: "Emerald" },
    { code: "blue", bg: "bg-blue-500", name: "Sapphire" },
    { code: "purple", bg: "bg-purple-500", name: "Violet" },
    { code: "amber", bg: "bg-amber-500", name: "Amber" },
    { code: "cyan", bg: "bg-cyan-500", name: "Cyan" },
  ];

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-md flex items-center justify-center p-4 animate-in fade-in duration-200">
      <div className="w-full max-w-md bg-zinc-950 border border-zinc-800 rounded-2xl shadow-2xl overflow-hidden flex flex-col">
        {/* Modal Header */}
        <div className="flex items-center justify-between p-4 border-b border-zinc-900 bg-zinc-900/50">
          <div className="flex items-center gap-2 font-bold text-white text-base">
            <Shield className="w-5 h-5 text-emerald-400" />
            <span>{isKurdish ? "ڕێکخستنەکانی LumaAI" : "LumaAI Settings"}</span>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-zinc-400 hover:text-white hover:bg-zinc-800 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Body */}
        <div className="p-5 space-y-6 overflow-y-auto max-h-[80vh] text-sm">
          {/* Language Selector */}
          <div className="space-y-2">
            <label className="text-xs font-semibold text-zinc-400 uppercase tracking-wider flex items-center gap-2">
              <Globe className="w-4 h-4 text-zinc-300" />
              <span>{isKurdish ? "زمانی سیستەم (Language)" : "System Language"}</span>
            </label>
            <div className="grid grid-cols-1 gap-2">
              {languages.map((lang) => (
                <button
                  key={lang.code}
                  onClick={() => onUpdateSettings({ language: lang.code })}
                  className={`flex items-center justify-between p-3 rounded-xl border text-left cursor-pointer transition-all ${
                    settings.language === lang.code
                      ? "bg-emerald-500/10 border-emerald-500/50 text-white font-semibold"
                      : "bg-zinc-900/80 border-zinc-800 text-zinc-400 hover:text-white hover:bg-zinc-900"
                  }`}
                >
                  <span>{lang.label}</span>
                  {settings.language === lang.code && <Check className="w-4 h-4 text-emerald-400" />}
                </button>
              ))}
            </div>
          </div>

          {/* Accent Theme Color */}
          <div className="space-y-2">
            <label className="text-xs font-semibold text-zinc-400 uppercase tracking-wider">
              {isKurdish ? "ڕەنگی ئەکسێنت (Accent Color)" : "Accent Color"}
            </label>
            <div className="flex items-center gap-3">
              {colors.map((c) => (
                <button
                  key={c.code}
                  onClick={() => onUpdateSettings({ accentColor: c.code })}
                  className={`w-9 h-9 rounded-full ${c.bg} flex items-center justify-center transition-transform cursor-pointer ${
                    settings.accentColor === c.code ? "ring-2 ring-white scale-110" : "opacity-70 hover:opacity-100"
                  }`}
                >
                  {settings.accentColor === c.code && <Check className="w-4 h-4 text-zinc-950 font-bold" />}
                </button>
              ))}
            </div>
          </div>

          {/* Voice Output */}
          <div className="flex items-center justify-between p-3 rounded-xl bg-zinc-900/80 border border-zinc-800">
            <div className="flex items-center gap-3">
              <Volume2 className="w-4 h-4 text-zinc-400" />
              <div>
                <div className="font-semibold text-zinc-200">
                  {isKurdish ? "خوێندنەوەی دەنگیی خۆکار" : "Auto Voice Read"}
                </div>
                <div className="text-xs text-zinc-500">
                  {isKurdish ? "وەڵامەکان بە دەنگ بخوێنەرەوە" : "Automatically speak AI responses"}
                </div>
              </div>
            </div>
            <input
              type="checkbox"
              checked={settings.autoVoiceOutput}
              onChange={(e) => onUpdateSettings({ autoVoiceOutput: e.target.checked })}
              className="w-5 h-5 accent-emerald-500 cursor-pointer rounded"
            />
          </div>

          {/* System Info */}
          <div className="p-3.5 rounded-xl bg-zinc-900/50 border border-zinc-800/80 space-y-1.5 text-xs text-zinc-400">
            <div className="flex items-center gap-2 font-semibold text-zinc-200 mb-1">
              <Info className="w-4 h-4 text-emerald-400" />
              <span>زانیاری لۆما LumaAI System</span>
            </div>
            <p>• Model Engine: Gemini 3.6 Flash & Pro Reasoning</p>
            <p>• Interface: ChatGPT Dark Luxury Minimalist</p>
            <p>• Version: 2.0.0 (Pro Production)</p>
          </div>

          {/* Clear All Chats Danger Button */}
          <div className="pt-2 border-t border-zinc-900">
            <button
              onClick={() => {
                if (
                  window.confirm(
                    isKurdish
                      ? "دڵنیایت لە سڕینەوەی هەموو گفتوگۆکان؟ ئەم کردارە پاشگەزبوونەوەی نییە."
                      : "Are you sure you want to clear all chat histories?"
                  )
                ) {
                  onClearAllChats();
                  onClose();
                }
              }}
              className="w-full flex items-center justify-center gap-2 p-3 rounded-xl bg-red-500/10 hover:bg-red-500/20 text-red-400 border border-red-500/30 transition-all font-semibold cursor-pointer"
            >
              <Trash2 className="w-4 h-4" />
              <span>{isKurdish ? "سڕینەوەی سەرجەم گفتوگۆکان" : "Clear All Chat History"}</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
