import React, { useState, useRef, useEffect } from "react";
import { AIModelMode } from "../types";
import { Zap, Brain, Globe, Image as ImageIcon, ChevronDown, Check } from "lucide-react";

interface ModelSelectorProps {
  currentMode: AIModelMode;
  onSelectMode: (mode: AIModelMode) => void;
  accentColor: string;
}

export const MODEL_OPTIONS: {
  id: AIModelMode;
  name: string;
  badge: string;
  description: string;
  icon: React.ElementType;
  badgeColor: string;
}[] = [
  {
    id: "flash",
    name: "Luma Flash",
    badge: "Fast & Smart",
    description: "Great for everyday tasks, writing, chatting, and quick questions.",
    icon: Zap,
    badgeColor: "bg-emerald-500/10 text-emerald-400 border-emerald-500/20",
  },
  {
    id: "reason",
    name: "Luma Thought & Code",
    badge: "Deep Reasoning",
    description: "Advanced model for coding, math, complex logic, and step-by-step thinking.",
    icon: Brain,
    badgeColor: "bg-purple-500/10 text-purple-400 border-purple-500/20",
  },
  {
    id: "search",
    name: "Luma Web Search",
    badge: "Real-time Web",
    description: "Connected to Google Search for live weather, sports, news, and facts.",
    icon: Globe,
    badgeColor: "bg-blue-500/10 text-blue-400 border-blue-500/20",
  },
  {
    id: "image",
    name: "Luma Vision & Image",
    badge: "AI Generator",
    description: "Generate images from text prompts or analyze uploaded photos.",
    icon: ImageIcon,
    badgeColor: "bg-amber-500/10 text-amber-400 border-amber-500/20",
  },
];

export const ModelSelector: React.FC<ModelSelectorProps> = ({
  currentMode,
  onSelectMode,
}) => {
  const [isOpen, setIsOpen] = useState(false);
  const dropdownRef = useRef<HTMLDivElement>(null);

  const selectedModel = MODEL_OPTIONS.find((m) => m.id === currentMode) || MODEL_OPTIONS[0];
  const IconComponent = selectedModel.icon;

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target as Node)) {
        setIsOpen(false);
      }
    };
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  return (
    <div className="relative" ref={dropdownRef}>
      <button
        onClick={() => setIsOpen(!isOpen)}
        className="flex items-center gap-2 px-3 py-1.5 rounded-xl bg-zinc-900 border border-zinc-800/80 hover:border-zinc-700 text-zinc-200 transition-all cursor-pointer shadow-sm text-sm font-medium"
      >
        <div className="p-1 rounded-lg bg-zinc-800 text-zinc-300">
          <IconComponent className="w-4 h-4" />
        </div>
        <span className="font-semibold">{selectedModel.name}</span>
        <span className={`text-[10px] px-1.5 py-0.5 rounded-md border font-mono ${selectedModel.badgeColor}`}>
          {selectedModel.badge}
        </span>
        <ChevronDown className={`w-3.5 h-3.5 text-zinc-400 transition-transform duration-200 ${isOpen ? "rotate-180" : ""}`} />
      </button>

      {isOpen && (
        <div className="absolute left-0 top-full mt-2 w-80 rounded-2xl bg-zinc-950 border border-zinc-800/90 shadow-2xl z-50 p-1.5 backdrop-blur-xl animate-in fade-in zoom-in-95 duration-150">
          <div className="px-3 py-2 text-xs font-semibold text-zinc-400 uppercase tracking-wider border-b border-zinc-900 mb-1">
            مۆدێل و بوارەکان (Select AI Mode)
          </div>
          <div className="space-y-1">
            {MODEL_OPTIONS.map((option) => {
              const OptionIcon = option.icon;
              const isSelected = option.id === currentMode;
              return (
                <button
                  key={option.id}
                  onClick={() => {
                    onSelectMode(option.id);
                    setIsOpen(false);
                  }}
                  className={`w-full text-left p-2.5 rounded-xl transition-all flex items-start gap-3 cursor-pointer ${
                    isSelected
                      ? "bg-zinc-800/90 border border-zinc-700/60 text-white"
                      : "hover:bg-zinc-900 text-zinc-300 hover:text-white"
                  }`}
                >
                  <div className={`p-2 rounded-xl mt-0.5 ${isSelected ? "bg-zinc-700 text-white" : "bg-zinc-900 text-zinc-400"}`}>
                    <OptionIcon className="w-4 h-4" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center justify-between">
                      <span className="text-sm font-medium">{option.name}</span>
                      {isSelected && <Check className="w-4 h-4 text-emerald-400 shrink-0" />}
                    </div>
                    <p className="text-xs text-zinc-400 line-clamp-2 mt-0.5 leading-relaxed">
                      {option.description}
                    </p>
                  </div>
                </button>
              );
            })}
          </div>
        </div>
      )}
    </div>
  );
};
