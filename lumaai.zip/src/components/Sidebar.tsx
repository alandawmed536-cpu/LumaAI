import React, { useState } from "react";
import { Conversation, AppLanguage } from "../types";
import {
  Plus,
  MessageSquare,
  Search,
  Pin,
  Trash2,
  Edit2,
  Download,
  Settings,
  Sparkles,
  ChevronLeft,
  X,
  Check,
} from "lucide-react";

interface SidebarProps {
  conversations: Conversation[];
  activeChatId: string | null;
  onSelectChat: (id: string) => void;
  onNewChat: () => void;
  onDeleteChat: (id: string) => void;
  onRenameChat: (id: string, newTitle: string) => void;
  onPinChat: (id: string) => void;
  onExportChat: (id: string) => void;
  onOpenSettings: () => void;
  isOpen: boolean;
  onCloseMobile: () => void;
  language: AppLanguage;
}

export const Sidebar: React.FC<SidebarProps> = ({
  conversations,
  activeChatId,
  onSelectChat,
  onNewChat,
  onDeleteChat,
  onRenameChat,
  onPinChat,
  onExportChat,
  onOpenSettings,
  isOpen,
  onCloseMobile,
  language,
}) => {
  const [searchTerm, setSearchTerm] = useState("");
  const [editingId, setEditingId] = useState<string | null>(null);
  const [editTitle, setEditTitle] = useState("");

  const isKurdish = language === "ku";

  // Filter conversations
  const filtered = conversations.filter((c) =>
    c.title.toLowerCase().includes(searchTerm.toLowerCase())
  );

  // Group by timeframe
  const now = Date.now();
  const ONE_DAY = 24 * 60 * 60 * 1000;

  const pinned = filtered.filter((c) => c.pinned);
  const unpinned = filtered.filter((c) => !c.pinned);

  const today = unpinned.filter((c) => now - c.updatedAt < ONE_DAY);
  const yesterday = unpinned.filter(
    (c) => now - c.updatedAt >= ONE_DAY && now - c.updatedAt < 2 * ONE_DAY
  );
  const previous7Days = unpinned.filter(
    (c) => now - c.updatedAt >= 2 * ONE_DAY && now - c.updatedAt < 7 * ONE_DAY
  );
  const older = unpinned.filter((c) => now - c.updatedAt >= 7 * ONE_DAY);

  const handleStartEdit = (c: Conversation, e: React.MouseEvent) => {
    e.stopPropagation();
    setEditingId(c.id);
    setEditTitle(c.title);
  };

  const handleSaveEdit = (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    if (editTitle.trim()) {
      onRenameChat(id, editTitle.trim());
    }
    setEditingId(null);
  };

  const renderChatItem = (c: Conversation) => {
    const isActive = c.id === activeChatId;
    const isEditing = editingId === c.id;

    return (
      <div
        key={c.id}
        onClick={() => {
          onSelectChat(c.id);
          onCloseMobile();
        }}
        className={`group relative flex items-center gap-2.5 p-2.5 rounded-xl transition-all cursor-pointer text-sm font-medium ${
          isActive
            ? "bg-zinc-800 text-white shadow-md border border-zinc-700/80"
            : "text-zinc-400 hover:text-zinc-200 hover:bg-zinc-900/90"
        }`}
      >
        <MessageSquare className={`w-4 h-4 shrink-0 ${isActive ? "text-emerald-400" : "text-zinc-500"}`} />

        {isEditing ? (
          <div className="flex items-center gap-1 flex-1 min-w-0" onClick={(e) => e.stopPropagation()}>
            <input
              type="text"
              value={editTitle}
              onChange={(e) => setEditTitle(e.target.value)}
              className="w-full bg-zinc-950 border border-zinc-700 text-white text-xs px-2 py-1 rounded focus:outline-none focus:border-emerald-500"
              autoFocus
            />
            <button
              onClick={(e) => handleSaveEdit(c.id, e)}
              className="p-1 rounded hover:bg-zinc-700 text-emerald-400"
            >
              <Check className="w-3.5 h-3.5" />
            </button>
          </div>
        ) : (
          <span className="flex-1 truncate text-xs md:text-sm">{c.title || "گفتوگۆی نوێ"}</span>
        )}

        {/* Hover Actions */}
        {!isEditing && (
          <div className="hidden group-hover:flex items-center gap-1 shrink-0 bg-zinc-900/90 px-1 py-0.5 rounded-lg border border-zinc-800">
            <button
              onClick={(e) => {
                e.stopPropagation();
                onPinChat(c.id);
              }}
              className={`p-1 rounded hover:bg-zinc-800 ${c.pinned ? "text-amber-400" : "text-zinc-400 hover:text-white"}`}
              title="پینکردن (Pin)"
            >
              <Pin className="w-3 h-3" />
            </button>
            <button
              onClick={(e) => handleStartEdit(c, e)}
              className="p-1 rounded hover:bg-zinc-800 text-zinc-400 hover:text-white"
              title="ناوەڕاستکردنەوە (Rename)"
            >
              <Edit2 className="w-3 h-3" />
            </button>
            <button
              onClick={(e) => {
                e.stopPropagation();
                onExportChat(c.id);
              }}
              className="p-1 rounded hover:bg-zinc-800 text-zinc-400 hover:text-white"
              title="داگرتن (Export)"
            >
              <Download className="w-3 h-3" />
            </button>
            <button
              onClick={(e) => {
                e.stopPropagation();
                onDeleteChat(c.id);
              }}
              className="p-1 rounded hover:bg-zinc-800 text-zinc-400 hover:text-red-400"
              title="سڕینەوە (Delete)"
            >
              <Trash2 className="w-3 h-3" />
            </button>
          </div>
        )}
      </div>
    );
  };

  return (
    <>
      {/* Mobile Backdrop */}
      {isOpen && (
        <div
          onClick={onCloseMobile}
          className="fixed inset-0 bg-black/80 backdrop-blur-sm z-40 md:hidden animate-in fade-in duration-200"
        />
      )}

      {/* Sidebar Container */}
      <aside
        className={`fixed md:static top-0 bottom-0 left-0 z-50 w-72 bg-zinc-950 border-r border-zinc-800/80 flex flex-col transition-transform duration-300 ease-in-out ${
          isOpen ? "translate-x-0" : "-translate-x-full md:translate-x-0"
        }`}
      >
        {/* Header Branding & New Chat */}
        <div className="p-4 border-b border-zinc-900 flex flex-col gap-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              <div className="p-2 rounded-xl bg-gradient-to-tr from-emerald-600 to-teal-400 shadow-md">
                <Sparkles className="w-4 h-4 text-zinc-950 font-bold" />
              </div>
              <span className="font-extrabold text-lg text-white tracking-tight">LumaAI</span>
            </div>
            <button
              onClick={onCloseMobile}
              className="p-1.5 rounded-lg text-zinc-400 hover:text-white hover:bg-zinc-900 md:hidden cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          <button
            onClick={() => {
              onNewChat();
              onCloseMobile();
            }}
            className="w-full flex items-center justify-between px-3.5 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-medium text-sm transition-all shadow-lg shadow-emerald-950/50 cursor-pointer"
          >
            <div className="flex items-center gap-2">
              <Plus className="w-4 h-4" />
              <span>{isKurdish ? "گفتوگۆی نوێ" : "New Chat"}</span>
            </div>
            <kbd className="hidden md:inline-block px-1.5 py-0.5 text-[10px] font-mono bg-emerald-700/60 rounded text-emerald-100">
              Ctrl N
            </kbd>
          </button>
        </div>

        {/* Search Conversations */}
        <div className="px-4 py-2 border-b border-zinc-900">
          <div className="relative">
            <Search className="w-3.5 h-3.5 absolute left-3 top-1/2 -translate-y-1/2 text-zinc-500" />
            <input
              type="text"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              placeholder={isKurdish ? "گەڕان لە گفتوگۆکان..." : "Search chats..."}
              className="w-full bg-zinc-900/90 border border-zinc-800 rounded-xl pl-9 pr-3 py-1.5 text-xs text-white placeholder-zinc-500 focus:outline-none focus:border-zinc-700"
            />
          </div>
        </div>

        {/* Chat History List */}
        <div className="flex-1 overflow-y-auto p-3 space-y-4 scrollbar-thin scrollbar-thumb-zinc-800">
          {filtered.length === 0 ? (
            <div className="text-center py-8 text-xs text-zinc-600 font-medium">
              {isKurdish ? "هیچ گفتوگۆیەک نەدۆزرایەوە" : "No chats found"}
            </div>
          ) : (
            <>
              {/* Pinned */}
              {pinned.length > 0 && (
                <div className="space-y-1">
                  <div className="px-2 py-1 text-[11px] font-semibold uppercase tracking-wider text-amber-400 flex items-center gap-1.5">
                    <Pin className="w-3 h-3" />
                    <span>پینکراوەکان (Pinned)</span>
                  </div>
                  {pinned.map(renderChatItem)}
                </div>
              )}

              {/* Today */}
              {today.length > 0 && (
                <div className="space-y-1">
                  <div className="px-2 py-1 text-[11px] font-semibold uppercase tracking-wider text-zinc-500">
                    {isKurdish ? "ئەمڕۆ" : "Today"}
                  </div>
                  {today.map(renderChatItem)}
                </div>
              )}

              {/* Yesterday */}
              {yesterday.length > 0 && (
                <div className="space-y-1">
                  <div className="px-2 py-1 text-[11px] font-semibold uppercase tracking-wider text-zinc-500">
                    {isKurdish ? "دوێنێ" : "Yesterday"}
                  </div>
                  {yesterday.map(renderChatItem)}
                </div>
              )}

              {/* Previous 7 Days */}
              {previous7Days.length > 0 && (
                <div className="space-y-1">
                  <div className="px-2 py-1 text-[11px] font-semibold uppercase tracking-wider text-zinc-500">
                    {isKurdish ? "٧ ڕۆژی ڕابردوو" : "Previous 7 Days"}
                  </div>
                  {previous7Days.map(renderChatItem)}
                </div>
              )}

              {/* Older */}
              {older.length > 0 && (
                <div className="space-y-1">
                  <div className="px-2 py-1 text-[11px] font-semibold uppercase tracking-wider text-zinc-500">
                    {isKurdish ? "کۆنتر" : "Older"}
                  </div>
                  {older.map(renderChatItem)}
                </div>
              )}
            </>
          )}
        </div>

        {/* Footer User & Settings */}
        <div className="p-3 border-t border-zinc-900 bg-zinc-950/80 space-y-2">
          <button
            onClick={onOpenSettings}
            className="w-full flex items-center gap-3 p-2.5 rounded-xl hover:bg-zinc-900 text-zinc-300 hover:text-white text-sm font-medium transition-colors cursor-pointer"
          >
            <Settings className="w-4 h-4 text-zinc-400" />
            <span className="flex-1 text-left text-xs md:text-sm">
              {isKurdish ? "ڕێکخستنەکان (Settings)" : "Settings"}
            </span>
          </button>

          <div className="flex items-center gap-3 p-2 rounded-xl bg-zinc-900/60 border border-zinc-800/80">
            <div className="w-8 h-8 rounded-full bg-gradient-to-tr from-emerald-500 to-teal-400 flex items-center justify-center text-zinc-950 font-bold text-xs shadow-md">
              L
            </div>
            <div className="flex-1 min-w-0">
              <div className="text-xs font-semibold text-zinc-200 truncate">Luma Pro User</div>
              <div className="text-[10px] text-emerald-400 font-mono flex items-center gap-1">
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
                <span>Online Engine</span>
              </div>
            </div>
          </div>
        </div>
      </aside>
    </>
  );
};
