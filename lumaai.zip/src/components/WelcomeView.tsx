import React from "react";
import { Sparkles, Code, Lightbulb, Compass, Image as ImageIcon, Zap, Globe, Brain } from "lucide-react";
import { AIModelMode, AppLanguage } from "../types";

interface WelcomeViewProps {
  onSelectPrompt: (prompt: string, mode?: AIModelMode) => void;
  language: AppLanguage;
}

export const WelcomeView: React.FC<WelcomeViewProps> = ({ onSelectPrompt, language }) => {
  const isKurdish = language === "ku";
  const isArabic = language === "ar";

  const suggestions = [
    {
      icon: Code,
      title: isKurdish ? "کۆد و پرۆگرامسازی" : isArabic ? "كتابة وتطوير الكود" : "Code & Development",
      prompt: isKurdish
        ? "تکایە پێکهاتەیەکی دروستکراو بە React و Tailwind CSS بە شێوازێکی مۆدێرن بنووسە."
        : isArabic
        ? "اكتب مكون React حديث باستخدام Tailwind CSS وتنسيق أنيق."
        : "Write a modern React component using Tailwind CSS with clean code.",
      mode: "reason" as AIModelMode,
      color: "from-purple-500/20 to-indigo-500/20 text-purple-400 border-purple-500/30",
    },
    {
      icon: Globe,
      title: isKurdish ? "گەڕان لە وێب" : isArabic ? "البحث في الويب" : "Real-time Search",
      prompt: isKurdish
        ? "نوێترین هەواڵ و پێشهاتەکانی ژیری دەستکرد AI چییە لەم هەفتەیەدا؟"
        : isArabic
        ? "ما هي أحدث أخبار وتطورات الذكاء الاصطناعي هذا الأسبوع؟"
        : "What are the latest developments and news in AI this week?",
      mode: "search" as AIModelMode,
      color: "from-blue-500/20 to-cyan-500/20 text-blue-400 border-blue-500/30",
    },
    {
      icon: ImageIcon,
      title: isKurdish ? "دروستکردنی وێنە" : isArabic ? "توليد الصور بالذكاء الاصطناعي" : "Generate AI Image",
      prompt: isKurdish
        ? "پڕۆمپتێک بۆ دروستکردنی وێنەیەکی فۆتۆڕیاڵیستی شاری هەولێر یان سلێمانی لە ئاینده‌دا بنووسە."
        : isArabic
        ? "أنشئ صورة لمستقبل مدينة حديثة بإضاءة سينمائية عالية الدقة."
        : "Generate a futuristic cyberpunk city with neon reflections and cinematic lighting.",
      mode: "image" as AIModelMode,
      color: "from-amber-500/20 to-orange-500/20 text-amber-400 border-amber-500/30",
    },
    {
      icon: Lightbulb,
      title: isKurdish ? "بیرۆکە و شیکردنەوە" : isArabic ? "أفكار وتحليلات" : "Brainstorm & Ideas",
      prompt: isKurdish
        ? "٥ بیرۆکەی داهێنەرانە بۆ پڕۆژەی بزوێنەری ژیری دەستکرد پێشنیار بکە."
        : isArabic
        ? "اقترح 5 أفكار مبتكرة لمشاريع تطبيقات الذكاء الاصطناعي."
        : "Suggest 5 innovative software startup ideas leveraging Generative AI.",
      mode: "flash" as AIModelMode,
      color: "from-emerald-500/20 to-teal-500/20 text-emerald-400 border-emerald-500/30",
    },
  ];

  return (
    <div className="flex-1 flex flex-col items-center justify-center p-6 md:p-12 text-center max-w-4xl mx-auto min-h-[calc(100vh-8rem)]">
      {/* Emblem Icon */}
      <div className="relative mb-6 group cursor-pointer">
        <div className="absolute -inset-1 rounded-3xl bg-gradient-to-r from-emerald-500 via-teal-500 to-cyan-500 blur-lg opacity-30 group-hover:opacity-60 transition duration-500"></div>
        <div className="relative w-20 h-20 rounded-3xl bg-zinc-950 border border-zinc-800 flex items-center justify-center shadow-2xl">
          <Sparkles className="w-10 h-10 text-emerald-400 animate-pulse" />
        </div>
      </div>

      {/* Main Title */}
      <h1 className="text-3xl md:text-5xl font-extrabold tracking-tight text-white mb-3 bg-gradient-to-r from-white via-zinc-200 to-zinc-400 bg-clip-text text-transparent">
        {isKurdish ? "LumaAI" : "LumaAI"}
      </h1>

      <p className="text-lg md:text-xl text-zinc-400 max-w-xl mb-10 leading-relaxed font-medium">
        {isKurdish
          ? "چی دەتوانیت ئەمڕۆ پێ بگەینم؟"
          : isArabic
          ? "كيف يمكنني مساعدتك اليوم؟"
          : "What can I help you with today?"}
      </p>

      {/* Suggestion Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-3.5 w-full text-left">
        {suggestions.map((item, idx) => {
          const Icon = item.icon;
          return (
            <button
              key={idx}
              onClick={() => onSelectPrompt(item.prompt, item.mode)}
              className={`p-4 rounded-2xl bg-zinc-950 border border-zinc-800/80 hover:border-zinc-700/80 hover:bg-zinc-900/80 transition-all duration-200 group text-left cursor-pointer flex items-start gap-4 shadow-lg`}
            >
              <div className={`p-3 rounded-xl bg-gradient-to-br ${item.color} border shrink-0 group-hover:scale-105 transition-transform`}>
                <Icon className="w-5 h-5" />
              </div>
              <div className="flex-1 min-w-0">
                <h3 className="text-sm font-semibold text-zinc-200 group-hover:text-white mb-1 flex items-center gap-2">
                  {item.title}
                </h3>
                <p className="text-xs text-zinc-400 line-clamp-2 leading-relaxed">
                  {item.prompt}
                </p>
              </div>
            </button>
          );
        })}
      </div>

      {/* Quick Capabilities Pill Bar */}
      <div className="mt-12 flex flex-wrap items-center justify-center gap-3 text-xs text-zinc-500">
        <span className="flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-zinc-900/80 border border-zinc-800 text-zinc-400">
          <Zap className="w-3.5 h-3.5 text-emerald-400" />
          {isKurdish ? "وەڵامی خێرا" : "Instant Answers"}
        </span>
        <span className="flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-zinc-900/80 border border-zinc-800 text-zinc-400">
          <Brain className="w-3.5 h-3.5 text-purple-400" />
          {isKurdish ? "شیکاری کۆد" : "Code Intelligence"}
        </span>
        <span className="flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-zinc-900/80 border border-zinc-800 text-zinc-400">
          <Globe className="w-3.5 h-3.5 text-blue-400" />
          {isKurdish ? "گەڕانی راستەوخۆ" : "Live Web Search"}
        </span>
      </div>
    </div>
  );
};
