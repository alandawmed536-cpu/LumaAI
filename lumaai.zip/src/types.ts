export type AIModelMode = "flash" | "reason" | "search" | "image";

export interface GroundingSource {
  title: string;
  uri: string;
}

export interface ChatMessage {
  id: string;
  role: "user" | "assistant";
  content: string;
  timestamp: number;
  image?: string; // Base64 or image URL
  sources?: GroundingSource[];
  isThinking?: boolean;
  modelUsed?: AIModelMode;
}

export interface Conversation {
  id: string;
  title: string;
  createdAt: number;
  updatedAt: number;
  messages: ChatMessage[];
  pinned?: boolean;
  modelMode: AIModelMode;
}

export type AccentColor = "emerald" | "blue" | "purple" | "amber" | "rose" | "cyan";
export type AppLanguage = "ku" | "en" | "ar";

export interface UserSettings {
  accentColor: AccentColor;
  language: AppLanguage;
  autoVoiceOutput: boolean;
  soundEffects: boolean;
  fontSize: "sm" | "md" | "lg";
  enableWebSearchDefault: boolean;
  customSystemPrompt?: string;
}
