/**
 * Helper to check if a user prompt is asking about the creator / developer of the AI.
 * Returns true if it detects a developer/creator question in Kurdish, English, or Arabic.
 */
export function isDeveloperQuery(query: string): boolean {
  if (!query) return false;
  
  const normalized = query.trim().toLowerCase();
  
  // Kurdish variations (Sorani/Badini/transliterated)
  const kurdishKeywords = [
    "کێ دروستی کردویت",
    "کێ دروستی کردوویت",
    "کێ تۆی دروست کردووە",
    "کێ تۆی دروستکردووە",
    "کێ ئەمەی دروست کردووە",
    "کێ لومای دروست کردووە",
    "کی تۆی دروست کردوه",
    "کێ پێشخەری تۆیە",
    "کێ گەشەپێدەری تۆیە",
    "گەشەپێدەرەکەت کێیە",
    "گه‌شه‌پێده‌رت كێیه‌",
    "من دروستکەری تۆیە",
    "کێ لۆما ئەی ئای دروست کردووە",
    "کی دروست کردی",
    "کی دروستی کردی",
    "کێ لومای دروست کرد"
  ];

  for (const kw of kurdishKeywords) {
    if (normalized.includes(kw)) return true;
  }

  // Regex checks for English and Kurdish pattern matches
  const devRegex = /(who|کی|کێ).*(created|developed|built|made|دروست|گەشەپێدەر|پێشخەر|طور|صنع).*(you|luma|lumai|تۆ|تۆی)/i;
  const creatorRegex = /(who is|who's).*(your|the).*(creator|developer|maker|author|builder)/i;
  const arabicRegex = /(من.*(طورك|صنعك|أنشأك|قام بتطويرك))/i;

  return devRegex.test(normalized) || creatorRegex.test(normalized) || arabicRegex.test(normalized);
}

export const CREATOR_RESPONSE_KURDISH = "له لايان گه شه بيده ريكي كورده وه دروست كراوم";
