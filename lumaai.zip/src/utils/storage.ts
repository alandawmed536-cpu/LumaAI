import { Conversation, UserSettings } from "../types";

const STORAGE_KEY_CHATS = "luma_ai_conversations_v1";
const STORAGE_KEY_ACTIVE_CHAT = "luma_ai_active_chat_id_v1";
const STORAGE_KEY_SETTINGS = "luma_ai_user_settings_v1";

export const DEFAULT_SETTINGS: UserSettings = {
  accentColor: "emerald",
  language: "ku",
  autoVoiceOutput: false,
  soundEffects: true,
  fontSize: "md",
  enableWebSearchDefault: false,
};

export function loadConversations(): Conversation[] {
  try {
    const raw = localStorage.getItem(STORAGE_KEY_CHATS);
    if (!raw) return [];
    return JSON.parse(raw);
  } catch (err) {
    console.error("Failed to load conversations from storage", err);
    return [];
  }
}

export function saveConversations(conversations: Conversation[]): void {
  try {
    localStorage.setItem(STORAGE_KEY_CHATS, JSON.stringify(conversations));
  } catch (err) {
    console.error("Failed to save conversations to storage", err);
  }
}

export function loadActiveChatId(): string | null {
  try {
    return localStorage.getItem(STORAGE_KEY_ACTIVE_CHAT);
  } catch {
    return null;
  }
}

export function saveActiveChatId(id: string | null): void {
  try {
    if (id) {
      localStorage.setItem(STORAGE_KEY_ACTIVE_CHAT, id);
    } else {
      localStorage.removeItem(STORAGE_KEY_ACTIVE_CHAT);
    }
  } catch (err) {
    console.error("Failed to save active chat ID", err);
  }
}

export function loadSettings(): UserSettings {
  try {
    const raw = localStorage.getItem(STORAGE_KEY_SETTINGS);
    if (!raw) return DEFAULT_SETTINGS;
    return { ...DEFAULT_SETTINGS, ...JSON.parse(raw) };
  } catch {
    return DEFAULT_SETTINGS;
  }
}

export function saveSettings(settings: UserSettings): void {
  try {
    localStorage.setItem(STORAGE_KEY_SETTINGS, JSON.stringify(settings));
  } catch (err) {
    console.error("Failed to save settings", err);
  }
}
