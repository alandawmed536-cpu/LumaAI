import React, { useState, useEffect, useRef } from "react";
import { Conversation, ChatMessage as ChatMessageType, AIModelMode, UserSettings } from "./types";
import {
  loadConversations,
  saveConversations,
  loadActiveChatId,
  saveActiveChatId,
  loadSettings,
  saveSettings,
} from "./utils/storage";
import { isDeveloperQuery, CREATOR_RESPONSE_KURDISH } from "./utils/creatorCheck";
import { Sidebar } from "./components/Sidebar";
import { ModelSelector } from "./components/ModelSelector";
import { WelcomeView } from "./components/WelcomeView";
import { ChatMessage } from "./components/ChatMessage";
import { ChatInput } from "./components/ChatInput";
import { SettingsModal } from "./components/SettingsModal";
import { Menu, Plus, Share2, Trash2, Download, Sparkles } from "lucide-react";

export default function App() {
  const [conversations, setConversations] = useState<Conversation[]>(loadConversations);
  const [activeChatId, setActiveChatId] = useState<string | null>(loadActiveChatId);
  const [settings, setSettings] = useState<UserSettings>(loadSettings);
  const [isLoading, setIsLoading] = useState(false);
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [settingsOpen, setSettingsOpen] = useState(false);
  const [currentMode, setCurrentMode] = useState<AIModelMode>("flash");

  const chatContainerRef = useRef<HTMLDivElement>(null);

  // Sync conversations to storage
  useEffect(() => {
    saveConversations(conversations);
  }, [conversations]);

  // Sync active chat ID to storage
  useEffect(() => {
    saveActiveChatId(activeChatId);
  }, [activeChatId]);

  // Sync settings to storage
  useEffect(() => {
    saveSettings(settings);
  }, [settings]);

  // Keyboard shortcut Ctrl+N for new chat
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === "n") {
        e.preventDefault();
        handleNewChat();
      }
    };
    window.addEventListener("keydown", handleKeyDown);
    return () => window.removeEventListener("keydown", handleKeyDown);
  }, [conversations]);

  // Auto scroll to bottom
  const scrollToBottom = () => {
    if (chatContainerRef.current) {
      chatContainerRef.current.scrollTop = chatContainerRef.current.scrollHeight;
    }
  };

  const activeChat = conversations.find((c) => c.id === activeChatId) || null;

  useEffect(() => {
    scrollToBottom();
  }, [activeChat?.messages.length, isLoading]);

  // Create new conversation
  const handleNewChat = () => {
    const newChat: Conversation = {
      id: `chat_${Date.now()}`,
      title: settings.language === "ku" ? "گفتوگۆی نوێ" : "New Chat",
      createdAt: Date.now(),
      updatedAt: Date.now(),
      messages: [],
      modelMode: currentMode,
    };
    setConversations((prev) => [newChat, ...prev]);
    setActiveChatId(newChat.id);
  };

  // Select conversation
  const handleSelectChat = (id: string) => {
    setActiveChatId(id);
  };

  // Delete conversation
  const handleDeleteChat = (id: string) => {
    setConversations((prev) => prev.filter((c) => c.id !== id));
    if (activeChatId === id) {
      const remaining = conversations.filter((c) => c.id !== id);
      setActiveChatId(remaining[0]?.id || null);
    }
  };

  // Rename conversation
  const handleRenameChat = (id: string, newTitle: string) => {
    setConversations((prev) =>
      prev.map((c) => (c.id === id ? { ...c, title: newTitle, updatedAt: Date.now() } : c))
    );
  };

  // Pin / Unpin
  const handlePinChat = (id: string) => {
    setConversations((prev) =>
      prev.map((c) => (c.id === id ? { ...c, pinned: !c.pinned } : c))
    );
  };

  // Export Chat
  const handleExportChat = (id: string) => {
    const chat = conversations.find((c) => c.id === id);
    if (!chat) return;

    let content = `# ${chat.title}\nDate: ${new Date(chat.createdAt).toLocaleString()}\n\n`;
    for (const msg of chat.messages) {
      content += `### ${msg.role === "user" ? "User" : "LumaAI"}\n${msg.content}\n\n`;
    }

    const blob = new Blob([content], { type: "text/markdown" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `${chat.title.replace(/[^a-z0-9]/gi, "_")}.md`;
    a.click();
    URL.revokeObjectURL(url);
  };

  // Send message
  const handleSendMessage = async (promptText: string, attachedImage?: string) => {
    if (!promptText.trim() && !attachedImage) return;

    let targetChatId = activeChatId;
    let currentChat = activeChat;

    // Create a new chat if none is active
    if (!targetChatId || !currentChat) {
      const newChat: Conversation = {
        id: `chat_${Date.now()}`,
        title: promptText.slice(0, 30) || (settings.language === "ku" ? "گفتوگۆ" : "Chat"),
        createdAt: Date.now(),
        updatedAt: Date.now(),
        messages: [],
        modelMode: currentMode,
      };
      setConversations((prev) => [newChat, ...prev]);
      targetChatId = newChat.id;
      setActiveChatId(newChat.id);
      currentChat = newChat;
    }

    const userMessage: ChatMessageType = {
      id: `msg_${Date.now()}`,
      role: "user",
      content: promptText,
      timestamp: Date.now(),
      image: attachedImage,
    };

    // Update conversation with user message
    const updatedMessages = [...currentChat.messages, userMessage];
    const updatedChatTitle =
      currentChat.messages.length === 0 ? promptText.slice(0, 30) || "گفتوگۆ" : currentChat.title;

    setConversations((prev) =>
      prev.map((c) =>
        c.id === targetChatId
          ? { ...c, messages: updatedMessages, title: updatedChatTitle, updatedAt: Date.now() }
          : c
      )
    );

    setIsLoading(true);

    try {
      // 1. FAST CREATOR CHECK: Check if asked "Who created you / developed you?"
      if (isDeveloperQuery(promptText)) {
        const assistantMessage: ChatMessageType = {
          id: `msg_ai_${Date.now()}`,
          role: "assistant",
          content: CREATOR_RESPONSE_KURDISH,
          timestamp: Date.now(),
          modelUsed: currentMode,
        };

        setConversations((prev) =>
          prev.map((c) =>
            c.id === targetChatId
              ? { ...c, messages: [...updatedMessages, assistantMessage], updatedAt: Date.now() }
              : c
          )
        );
        setIsLoading(false);

        // Auto read voice if enabled
        if (settings.autoVoiceOutput && "speechSynthesis" in window) {
          const u = new SpeechSynthesisUtterance(CREATOR_RESPONSE_KURDISH);
          window.speechSynthesis.speak(u);
        }
        return;
      }

      // 2. IMAGE GENERATION MODE
      if (currentMode === "image" || promptText.toLowerCase().startsWith("generate image:")) {
        const res = await fetch("/api/generate-image", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ prompt: promptText }),
        });

        const data = await res.json();

        if (data.imageUrl) {
          const assistantMessage: ChatMessageType = {
            id: `msg_ai_${Date.now()}`,
            role: "assistant",
            content: data.caption || "ئەمەش وێنە دروستکراوەکە بە بەکارهێنانی LumaAI Vision:",
            timestamp: Date.now(),
            image: data.imageUrl,
            modelUsed: "image",
          };

          setConversations((prev) =>
            prev.map((c) =>
              c.id === targetChatId
                ? { ...c, messages: [...updatedMessages, assistantMessage], updatedAt: Date.now() }
                : c
            )
          );
        } else {
          throw new Error(data.error || "Image generation failed");
        }
      } else {
        // 3. TEXT CHAT MODE (Flash, Reason, Search)
        const payloadMessages = updatedMessages.map((m) => ({
          role: m.role,
          content: m.content,
          image: m.image,
        }));

        const res = await fetch("/api/chat", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            messages: payloadMessages,
            model: "gemini-3.6-flash",
            enableWebSearch: currentMode === "search",
            isReasoning: currentMode === "reason",
            image: attachedImage,
          }),
        });

        const data = await res.json();

        const assistantText =
          data.text || data.fallbackText || "هیچ وەڵامێک وەرنگەیرا. تکایە دووبارە هەوڵبدەرەوە.";

        const assistantMessage: ChatMessageType = {
          id: `msg_ai_${Date.now()}`,
          role: "assistant",
          content: assistantText,
          timestamp: Date.now(),
          sources: data.sources || [],
          modelUsed: currentMode,
        };

        setConversations((prev) =>
          prev.map((c) =>
            c.id === targetChatId
              ? { ...c, messages: [...updatedMessages, assistantMessage], updatedAt: Date.now() }
              : c
          )
        );

        if (settings.autoVoiceOutput && "speechSynthesis" in window) {
          const u = new SpeechSynthesisUtterance(assistantText);
          window.speechSynthesis.speak(u);
        }
      }
    } catch (err: any) {
      console.error("Error in AI response:", err);
      const errorMessage: ChatMessageType = {
        id: `msg_err_${Date.now()}`,
        role: "assistant",
        content: "داواکارییەکە ئەنجام نەدرا. تکایە پەیوەندی هێڵ بپشکنەوە و دووبارە هەوڵبدەرەوە.",
        timestamp: Date.now(),
        modelUsed: currentMode,
      };

      setConversations((prev) =>
        prev.map((c) =>
          c.id === targetChatId
            ? { ...c, messages: [...updatedMessages, errorMessage], updatedAt: Date.now() }
            : c
        )
      );
    } finally {
      setIsLoading(false);
    }
  };

  // Select quick prompt from Welcome view
  const handleSelectPrompt = (prompt: string, mode?: AIModelMode) => {
    if (mode) setCurrentMode(mode);
    handleSendMessage(prompt);
  };

  return (
    <div className="flex h-screen w-screen overflow-hidden bg-black text-zinc-100 font-sans antialiased selection:bg-emerald-500/30 selection:text-white">
      {/* Sidebar Navigation Menu */}
      <Sidebar
        conversations={conversations}
        activeChatId={activeChatId}
        onSelectChat={handleSelectChat}
        onNewChat={handleNewChat}
        onDeleteChat={handleDeleteChat}
        onRenameChat={handleRenameChat}
        onPinChat={handlePinChat}
        onExportChat={handleExportChat}
        onOpenSettings={() => setSettingsOpen(true)}
        isOpen={sidebarOpen}
        onCloseMobile={() => setSidebarOpen(false)}
        language={settings.language}
      />

      {/* Main Chat Canvas */}
      <div className="flex-1 flex flex-col h-full min-w-0 bg-black relative">
        {/* Header Bar */}
        <header className="h-14 border-b border-zinc-900 px-4 flex items-center justify-between shrink-0 bg-black/90 backdrop-blur-md z-10">
          <div className="flex items-center gap-3">
            <button
              onClick={() => setSidebarOpen(true)}
              className="p-2 rounded-xl text-zinc-400 hover:text-white hover:bg-zinc-900 md:hidden cursor-pointer"
            >
              <Menu className="w-5 h-5" />
            </button>

            {/* Model Mode Dropdown */}
            <ModelSelector
              currentMode={currentMode}
              onSelectMode={(mode) => setCurrentMode(mode)}
              accentColor={settings.accentColor}
            />
          </div>

          {/* Action Buttons */}
          <div className="flex items-center gap-1.5">
            <button
              onClick={handleNewChat}
              className="p-2 rounded-xl text-zinc-400 hover:text-white hover:bg-zinc-900 transition-colors cursor-pointer"
              title="گفتوگۆی نوێ (New Chat)"
            >
              <Plus className="w-4 h-4" />
            </button>

            {activeChat && activeChat.messages.length > 0 && (
              <>
                <button
                  onClick={() => handleExportChat(activeChat.id)}
                  className="p-2 rounded-xl text-zinc-400 hover:text-white hover:bg-zinc-900 transition-colors cursor-pointer"
                  title="داگرتنی گفتوگۆ (Export Markdown)"
                >
                  <Download className="w-4 h-4" />
                </button>

                <button
                  onClick={() => handleDeleteChat(activeChat.id)}
                  className="p-2 rounded-xl text-zinc-400 hover:text-red-400 hover:bg-zinc-900 transition-colors cursor-pointer"
                  title="سڕینەوەی گفتوگۆ (Delete Chat)"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </>
            )}
          </div>
        </header>

        {/* Messages Body or Welcome View */}
        <div ref={chatContainerRef} className="flex-1 overflow-y-auto scrollbar-thin scrollbar-thumb-zinc-800">
          {!activeChat || activeChat.messages.length === 0 ? (
            <WelcomeView
              onSelectPrompt={handleSelectPrompt}
              language={settings.language}
            />
          ) : (
            <div className="pb-8">
              {activeChat.messages.map((msg, idx) => (
                <ChatMessage
                  key={msg.id || idx}
                  message={msg}
                  accentColor={settings.accentColor}
                  onRegenerate={
                    msg.role === "assistant" && idx === activeChat.messages.length - 1
                      ? () => {
                          const lastUserMsg = [...activeChat.messages]
                            .reverse()
                            .find((m) => m.role === "user");
                          if (lastUserMsg) {
                            handleSendMessage(lastUserMsg.content, lastUserMsg.image);
                          }
                        }
                      : undefined
                  }
                />
              ))}

              {/* Typing indicator */}
              {isLoading && (
                <div className="w-full py-6 px-4 md:px-6 bg-zinc-950/80 border-b border-zinc-900/60">
                  <div className="max-w-4xl mx-auto flex gap-4 md:gap-6 items-center">
                    <div className="w-8 h-8 rounded-full bg-gradient-to-tr from-emerald-600 to-teal-400 p-0.5 shadow-md flex items-center justify-center animate-pulse">
                      <div className="w-full h-full bg-zinc-950 rounded-full flex items-center justify-center">
                        <Sparkles className="w-4 h-4 text-emerald-400" />
                      </div>
                    </div>
                    <div className="flex items-center gap-1.5 text-zinc-400 text-sm font-medium">
                      <span>LumaAI بیر دەکاتەوە</span>
                      <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-bounce" />
                      <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-bounce delay-100" />
                      <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-bounce delay-200" />
                    </div>
                  </div>
                </div>
              )}
            </div>
          )}
        </div>

        {/* Input Dock */}
        <ChatInput
          onSendMessage={handleSendMessage}
          isLoading={isLoading}
          onStop={() => setIsLoading(false)}
          currentMode={currentMode}
          onToggleMode={(m) => setCurrentMode(m)}
          language={settings.language}
        />
      </div>

      {/* Settings Modal */}
      <SettingsModal
        isOpen={settingsOpen}
        onClose={() => setSettingsOpen(false)}
        settings={settings}
        onUpdateSettings={(newSet) => setSettings((prev) => ({ ...prev, ...newSet }))}
        onClearAllChats={() => {
          setConversations([]);
          setActiveChatId(null);
        }}
      />
    </div>
  );
}
